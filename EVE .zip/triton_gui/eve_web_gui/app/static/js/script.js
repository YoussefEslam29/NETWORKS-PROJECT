(function() {
    'use strict';

    const CONFIG = {
        NOTIFICATION_DURATION: 2500,
        CAMERA_WS_PORT: 9999,
        CAMERA_RECONNECT_DELAY: 3000,
        MAX_LOGS: 200,
        CAM_FILTERS: {
            day:   'brightness(1.15) contrast(1.6) saturate(1.4) hue-rotate(15deg)',
            night: 'brightness(1.4) contrast(2.0) saturate(0.9)'
        }
    };

    const LOG_LEVELS = ['DEBUG', 'INFO', 'WARN', 'ERROR'];
    const LOG_TITLES = {
        DEBUG: 'Debug Logs',
        INFO: 'Info Logs',
        WARN: 'Warning Logs',
        ERROR: 'Error Logs'
    };

    const state = {
        gamepadId: null,
        controllerConnected: false,
        cameraWs: null,
        cameraReconnectTimer: null,
        slotMapping: [],
        dragSourceIndex: null,
        lastFrames: {},
        pendingAction: null,
        activeLogLevel: 'INFO',
        logsByLevel: { DEBUG: [], INFO: [], WARN: [], ERROR: [] },
        cameraVisualFilter: null,
        localStreams: {},
        localLabels: {}
    };

    const DOM = {
        notification: document.getElementById('notification'),
        notificationTitle: document.getElementById('notification-title'),
        notificationMessage: document.getElementById('notification-message'),
        controlBox: document.getElementById('control-box'),
        loggerSection: document.getElementById('logger-section'),
        loggerButtons: document.querySelectorAll('.logger-trigger'),
        loggerPanel: document.getElementById('logger-panel'),
        loggerMessages: document.getElementById('logger-messages'),
        loggerTitle: document.getElementById('logger-title'),
        loggerClose: document.getElementById('logger-close'),
        camVisBtns: document.querySelectorAll('.cam-vis-btn'),
        cameraGrid: document.getElementById('camera-grid')
    };

    const loggerCounts = {
        DEBUG: document.getElementById('logger-count-debug'),
        INFO: document.getElementById('logger-count-info'),
        WARN: document.getElementById('logger-count-warn'),
        ERROR: document.getElementById('logger-count-error')
    };

    const socket = window._appSocket = io({ transports: ['polling'] });

    // ========== UTILITIES ==========
    function notify(title, message, type = 'error') {
        DOM.notificationTitle.textContent = title;
        DOM.notificationMessage.textContent = message;
        DOM.notification.classList.remove('error', 'success');
        DOM.notification.classList.add(type, 'show');
        setTimeout(() => DOM.notification.classList.remove('show'), CONFIG.NOTIFICATION_DURATION);
    }

    // ========== CAMERA VISUAL FILTER ==========
    function applyVisualFilter(key) {
        const deactivate = state.cameraVisualFilter === key;
        state.cameraVisualFilter = deactivate ? null : key;
        DOM.camVisBtns.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.filter === state.cameraVisualFilter);
        });
        const filterVal = state.cameraVisualFilter ? CONFIG.CAM_FILTERS[state.cameraVisualFilter] : '';
        document.querySelectorAll('.camera-feed').forEach(canvas => {
            canvas.style.filter = filterVal;
        });
    }

    function safeFixed(value, decimals = 1) {
        return (typeof value === 'number') ? value.toFixed(decimals) : '—';
    }

    function clamp(value, min, max) {
        return Math.min(Math.max(value, min), max);
    }

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // ========== LOGGER ==========
    const hasLogger = !!DOM.loggerMessages;

    function closeLogger() {
        if (!DOM.loggerSection) return;
        DOM.loggerSection.classList.remove('active');
    }

    function renderLogPanel(level) {
        if (!DOM.loggerMessages) return;
        const logs = state.logsByLevel[level] || [];
        DOM.loggerMessages.innerHTML = '';

        if (!logs.length) {
            DOM.loggerMessages.innerHTML = '<div class="logger-empty">No logs yet...</div>';
            return;
        }

        logs.forEach((entry) => {
            const node = document.createElement('div');
            node.className = `log-entry ${entry.level}`;
            node.innerHTML = `
                <span class="log-timestamp">${entry.timestamp}</span>
                <span class="log-level">${entry.level}</span>
                <span class="log-message">${escapeHtml(entry.message)}</span>
            `;
            DOM.loggerMessages.appendChild(node);
        });

        DOM.loggerMessages.scrollTop = DOM.loggerMessages.scrollHeight;
    }

    function updateLoggerCount(level) {
        const countEl = loggerCounts[level];
        if (!countEl) return;
        const count = state.logsByLevel[level].length;
        countEl.textContent = count;
        countEl.classList.remove('has-debug', 'has-info', 'has-warnings', 'has-errors');
        if (count > 0) {
            if (level === 'DEBUG') countEl.classList.add('has-debug');
            if (level === 'INFO') countEl.classList.add('has-info');
            if (level === 'WARN') countEl.classList.add('has-warnings');
            if (level === 'ERROR') countEl.classList.add('has-errors');
        }
    }

    function setActiveLogLevel(level) {
        state.activeLogLevel = level;
        if (DOM.loggerTitle) DOM.loggerTitle.textContent = LOG_TITLES[level] || 'System Log';
        DOM.loggerButtons.forEach((btn) => {
            btn.classList.toggle('active', btn.dataset.level === level);
        });
        renderLogPanel(level);
    }

    function openLogger(level) {
        if (!DOM.loggerSection) return;
        const isActive = DOM.loggerSection.classList.contains('active');
        if (isActive && state.activeLogLevel === level) {
            closeLogger();
            return;
        }
        setActiveLogLevel(level);
        DOM.loggerSection.classList.add('active');
    }

    function addLogEntry(timestamp, level, message) {
        if (level === 'FATAL') return;
        const normalizedLevel = LOG_LEVELS.includes(level) ? level : 'INFO';
        const logList = state.logsByLevel[normalizedLevel];
        if (DOM.loggerMessages) {
            const emptyState = DOM.loggerMessages.querySelector('.logger-empty');
            if (emptyState) emptyState.remove();
        }

        logList.push({ timestamp, level: normalizedLevel, message });
        while (logList.length > CONFIG.MAX_LOGS) {
            logList.shift();
        }

        updateLoggerCount(normalizedLevel);

        if (DOM.loggerSection && DOM.loggerSection.classList.contains('active') && state.activeLogLevel === normalizedLevel) {
            renderLogPanel(normalizedLevel);
        }
    }

    function initLogger() {
        if (!hasLogger) return;
        DOM.loggerMessages.innerHTML = '<div class="logger-empty">No logs yet...</div>';
        DOM.loggerButtons.forEach((btn) => {
            btn.onclick = () => openLogger(btn.dataset.level);
        });
        if (DOM.loggerClose) DOM.loggerClose.onclick = (e) => {
            e.stopPropagation();
            closeLogger();
        };
        LOG_LEVELS.forEach((level) => updateLoggerCount(level));
    }

    // Browser Gamepad API path disabled.
    // Controller input now comes from Python via pygame/SDL for consistent wired/Bluetooth handling.

    // ========== SOCKET EVENT HANDLERS ==========
    socket.on('connect', () => {
        socket.emit('get_mapping', {
            device_id:    window.GamepadManager ? window.GamepadManager.getDeviceId() : '',
            profile_name: window.GamepadManager ? (window.GamepadManager.getActiveProfile() || 'Default') : 'Default',
        });
    });

    socket.on('mapping', (data) => {
        window._tritonMapping = data;
    });

    socket.on('notification', (data) => {
        notify(
            data.success ? 'Success' : `Error ${data.error_code}`,
            data.message,
            data.success ? 'success' : 'error'
        );
    });

    socket.on('terminal_log', (data) => {
        addLogEntry(data.timestamp, data.level, data.message);
    });

    socket.on('controller_status', (data) => {
        const wasConnected = state.controllerConnected;
        state.controllerConnected = !!data.connected;
        state.gamepadId = data.name || null;

        DOM.controlBox.classList.toggle('connected', state.controllerConnected);

        if (state.controllerConnected && (!wasConnected || state.gamepadId !== data.name)) {
            notify('Controller', data.name || 'Connected', 'success');
        } else if (!state.controllerConnected && wasConnected) {
            notify('Controller', 'Disconnected', 'error');
        }
    });

    socket.on('robot_status', function(data) {
        var ex = document.getElementById('euler-x');
        var ey = document.getElementById('euler-y');
        var ez = document.getElementById('euler-z');
        var dl = document.getElementById('dist-left');
        var dr = document.getElementById('dist-right');
        if (ex) ex.textContent = data.euler.x.toFixed(2) + '°';
        if (ey) ey.textContent = data.euler.y.toFixed(2) + '°';
        if (ez) ez.textContent = data.euler.z.toFixed(2) + '°';
        if (dl) dl.textContent = data.distance_cm[0] + ' cm';
        if (dr) dr.textContent = data.distance_cm[1] + ' cm';
    });

    socket.on('cam_layout_request', () => {
        socket.emit('cam_layout_state', { slotMapping: state.slotMapping.slice(), localLabels: Object.assign({}, state.localLabels) });
    });

    socket.on('cam_layout_update', (data) => {
        if (Array.isArray(data.slotMapping)) {
            state.slotMapping = data.slotMapping;
            renderAllSlots();
        }
    });

    socket.on('cam_maximize', (data) => {
        const slot = document.getElementById(`cam-${data.slotIndex}`);
        if (slot && slot.classList.contains('online')) {
            slot.classList.add('fullscreen');
        }
    });

    socket.on('cam_minimize', (data) => {
        const slot = document.getElementById(`cam-${data.slotIndex}`);
        if (slot) slot.classList.remove('fullscreen');
    });

    socket.on('cam_remove_slot', (data) => {
        const index = data.slotIndex;
        if (index < 0 || index >= state.slotMapping.length || state.slotMapping.length <= 1) return;
        const removed = state.slotMapping.splice(index, 1)[0];
        if (isLocalCamera(removed)) {
            const devId = getLocalDeviceId(removed);
            if (state.localStreams[devId]) {
                state.localStreams[devId].getTracks().forEach(t => t.stop());
                delete state.localStreams[devId];
            }
            delete state.localLabels[devId];
        }
        renderAllSlots();
    });

    socket.on('disconnect', () => {
        state.controllerConnected = false;
        state.gamepadId = null;
        DOM.controlBox.classList.remove('connected');
    });

    DOM.camVisBtns.forEach(btn => {
        btn.onclick = () => applyVisualFilter(btn.dataset.filter);
    });

    // ========== KEYBOARD UI SHORTCUTS ==========
    document.addEventListener('keydown', (e) => {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
        if (e.key === 'Escape') {
            closeLogger();
            document.querySelectorAll('.camera-slot.fullscreen').forEach(s => {
                const slotIndex = parseInt(s.id.replace('cam-', ''));
                socket.emit('cam_minimize', { slotIndex });
                s.classList.remove('fullscreen');
            });
            if (document.fullscreenElement) document.exitFullscreen();
        }
        if (e.key === 'f' || e.key === 'F') {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen();
            } else {
                document.exitFullscreen();
            }
        }
    });

    document.addEventListener('fullscreenchange', () => {
        if (!document.fullscreenElement) {
            document.querySelectorAll('.camera-slot.fullscreen').forEach(s => {
                const slotIndex = parseInt(s.id.replace('cam-', ''));
                socket.emit('cam_minimize', { slotIndex });
                s.classList.remove('fullscreen');
            });
        }
    });

    document.addEventListener('click', (e) => {
        // Close logger when clicking outside
        if (DOM.loggerSection && !DOM.loggerSection.contains(e.target)) {
            closeLogger();
        }
    });

    // ========== LOCAL CAMERA HELPERS ==========
    function isLocalCamera(id) {
        return typeof id === 'string' && id.startsWith('local-');
    }

    function getLocalDeviceId(slotId) {
        return slotId.slice(6);
    }

    // ========== SLOT CONTROLS ==========
    function syncSlotControls() {
        const removeBtn = document.getElementById('cam-slot-remove');
        if (removeBtn) removeBtn.disabled = state.slotMapping.length <= 1;
    }

    function addSlot() {
        const intIds = state.slotMapping.filter(id => typeof id === 'number');
        const nextId = intIds.length > 0 ? Math.max(...intIds) + 1 : 0;
        state.slotMapping.push(nextId);
        renderAllSlots();
    }

    function removeSlot() {
        if (state.slotMapping.length <= 1) return;
        const removed = state.slotMapping[state.slotMapping.length - 1];
        state.slotMapping.pop();
        if (isLocalCamera(removed)) {
            const devId = getLocalDeviceId(removed);
            if (state.localStreams[devId]) {
                state.localStreams[devId].getTracks().forEach(t => t.stop());
                delete state.localStreams[devId];
            }
            delete state.localLabels[devId];
        }
        renderAllSlots();
    }

    // ========== CAMERA GRID ==========
    function drawFrameToCanvas(canvas, jpegBytes) {
        const blob = new Blob([jpegBytes], { type: 'image/jpeg' });
        return createImageBitmap(blob).then((bitmap) => {
            canvas.width  = bitmap.width;
            canvas.height = bitmap.height;
            canvas.getContext('2d').drawImage(bitmap, 0, 0);
            bitmap.close();
        });
    }

    function createSlotElement(index) {
        const cameraId = state.slotMapping[index];
        const isLocal = isLocalCamera(cameraId);
        const slot = document.createElement('div');
        slot.className = 'camera-slot offline';
        slot.id = `cam-${index}`;
        slot.draggable = true;

        if (isLocal) {
            const deviceId = getLocalDeviceId(cameraId);
            const label = state.localLabels[deviceId] || 'Local Camera';
            slot.innerHTML =
                `<div class="camera-label">${label}</div>` +
                `<video class="camera-feed" id="feed-${index}" autoplay playsinline muted></video>` +
                `<div class="camera-offline">OFFLINE</div>`;
        } else {
            slot.innerHTML =
                `<div class="camera-label">Camera ${cameraId}</div>` +
                `<canvas class="camera-feed" id="feed-${index}"></canvas>` +
                `<div class="camera-offline">OFFLINE</div>`;
        }

        const canvas = slot.querySelector('.camera-feed');
        if (state.cameraVisualFilter) canvas.style.filter = CONFIG.CAM_FILTERS[state.cameraVisualFilter];

        // Per-slot remove button (bottom-right, only when >1 slot)
        if (state.slotMapping.length > 1) {
            const removeBtn = document.createElement('button');
            removeBtn.className = 'cam-slot-remove';
            removeBtn.textContent = '\u00d7';
            removeBtn.title = 'Remove camera';
            removeBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                if (state.slotMapping.length <= 1) return;
                const removed = state.slotMapping.splice(index, 1)[0];
                if (isLocalCamera(removed)) {
                    const devId = getLocalDeviceId(removed);
                    if (state.localStreams[devId]) {
                        state.localStreams[devId].getTracks().forEach(t => t.stop());
                        delete state.localStreams[devId];
                    }
                    delete state.localLabels[devId];
                }
                renderAllSlots();
            });
            slot.appendChild(removeBtn);
        }

        // Fullscreen click
        slot.addEventListener('click', (e) => {
            if (!slot.classList.contains('fullscreen') && slot.classList.contains('online')) {
                slot.classList.add('fullscreen');
                socket.emit('cam_maximize', { slotIndex: index });
            }
        });

        // Drag events
        slot.addEventListener('dragstart', () => {
            state.dragSourceIndex = index;
            slot.classList.add('dragging');
        });

        slot.addEventListener('dragend', () => {
            slot.classList.remove('dragging');
            state.dragSourceIndex = null;
        });

        slot.addEventListener('dragover', (e) => {
            e.preventDefault();
            slot.classList.add('drag-over');
        });

        slot.addEventListener('dragleave', () => {
            slot.classList.remove('drag-over');
        });

        slot.addEventListener('drop', (e) => {
            e.preventDefault();
            slot.classList.remove('drag-over');
            const from = state.dragSourceIndex;
            const to = index;
            if (from !== null && from !== to) {
                const temp = state.slotMapping[from];
                state.slotMapping[from] = state.slotMapping[to];
                state.slotMapping[to] = temp;
                renderAllSlots();
            }
        });

        return slot;
    }

    function updateGridColumns() {
        const count = state.slotMapping.length;
        let cols;
        if (count <= 1) cols = '1fr';
        else if (count <= 4) cols = '1fr 1fr';
        else if (count <= 6) cols = '1fr 1fr 1fr';
        else cols = 'repeat(auto-fill, minmax(300px, 1fr))';
        DOM.cameraGrid.style.gridTemplateColumns = cols;
    }

    function renderAllSlots() {
        DOM.cameraGrid.querySelectorAll('.camera-slot').forEach(el => el.remove());

        for (let i = 0; i < state.slotMapping.length; i++) {
            const slotEl = createSlotElement(i);
            DOM.cameraGrid.appendChild(slotEl);

            const cameraId = state.slotMapping[i];
            if (isLocalCamera(cameraId)) {
                const deviceId = getLocalDeviceId(cameraId);
                const video = slotEl.querySelector('.camera-feed');
                if (video && state.localStreams[deviceId]) {
                    video.srcObject = state.localStreams[deviceId];
                    slotEl.classList.add('online');
                    slotEl.classList.remove('offline');
                }
            } else {
                const canvas = slotEl.querySelector('.camera-feed');
                if (canvas && state.lastFrames[cameraId]) {
                    drawFrameToCanvas(canvas, state.lastFrames[cameraId]).then(() => {
                        slotEl.classList.add('online');
                        slotEl.classList.remove('offline');
                    }).catch(() => {});
                }
            }
        }

        updateGridColumns();
        socket.emit('cam_layout_state', { slotMapping: state.slotMapping.slice(), localLabels: Object.assign({}, state.localLabels) });
        syncSlotControls();
    }

    function initCameraGrid() {
        state.slotMapping = [];
        renderAllSlots();
    }

    // ========== CAMERA STREAM ==========
    function connectCamera() {
        const wsUrl = `ws://${window.location.hostname}:${CONFIG.CAMERA_WS_PORT}`;

        try {
            state.cameraWs = new WebSocket(wsUrl);
            state.cameraWs.binaryType = 'arraybuffer';

            state.cameraWs.onopen = () => {
                notify('Cameras', 'Stream connected', 'success');
                if (state.cameraReconnectTimer) {
                    clearTimeout(state.cameraReconnectTimer);
                    state.cameraReconnectTimer = null;
                }
            };

            state.cameraWs.onclose = () => {
                state.lastFrames = {};
                for (let i = 0; i < state.slotMapping.length; i++) {
                    if (isLocalCamera(state.slotMapping[i])) continue;
                    const slot = document.getElementById(`cam-${i}`);
                    if (slot) {
                        slot.classList.remove('online');
                        slot.classList.add('offline');
                    }
                }
                scheduleCameraReconnect();
            };

            state.cameraWs.onerror = (err) => console.error('Camera error:', err);

            state.cameraWs.onmessage = (e) => {
                if (!(e.data instanceof ArrayBuffer)) return;
                const buf = e.data;
                const view = new DataView(buf);
                let offset = 0;
                const numCams = view.getUint8(offset++);

                const thisFrames = {};
                let slotsChanged = false;
                for (let i = 0; i < numCams; i++) {
                    const camId = view.getUint8(offset++);
                    const jpegSize = view.getUint32(offset, true); offset += 4;
                    const jpegBytes = new Uint8Array(buf, offset, jpegSize); offset += jpegSize;
                    thisFrames[camId] = jpegBytes;
                    state.lastFrames[camId] = jpegBytes;
                    if (!state.slotMapping.includes(camId)) {
                        state.slotMapping.push(camId);
                        slotsChanged = true;
                    }
                }

                if (slotsChanged) renderAllSlots();

                for (let i = 0; i < state.slotMapping.length; i++) {
                    const camId = state.slotMapping[i];
                    if (isLocalCamera(camId)) continue;
                    const slot = document.getElementById(`cam-${i}`);
                    const canvas = document.getElementById(`feed-${i}`);
                    if (thisFrames[camId] && slot && canvas) {
                        drawFrameToCanvas(canvas, thisFrames[camId]).then(() => {
                            slot.classList.add('online');
                            slot.classList.remove('offline');
                        }).catch(() => {});
                    }
                }
            };
        } catch (err) {
            console.error('Camera connection failed:', err);
            scheduleCameraReconnect();
        }
    }

    function scheduleCameraReconnect() {
        if (state.cameraReconnectTimer) return;
        state.cameraReconnectTimer = setTimeout(() => {
            state.cameraReconnectTimer = null;
            connectCamera();
        }, CONFIG.CAMERA_RECONNECT_DELAY);
    }

    // ========== LOCAL CAMERAS ==========
    async function refreshLocalCameras() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return;

        try {
            const devices = await navigator.mediaDevices.enumerateDevices();
            const videoDevices = devices.filter(function (d) { return d.kind === 'videoinput'; });
            const activeDeviceIds = new Set(videoDevices.map(function (d) { return d.deviceId; }));
            let changed = false;

            // Remove unplugged cameras
            var currentLocal = state.slotMapping.filter(isLocalCamera);
            for (var j = 0; j < currentLocal.length; j++) {
                var localId = currentLocal[j];
                var devId = getLocalDeviceId(localId);
                if (!activeDeviceIds.has(devId)) {
                    if (state.localStreams[devId]) {
                        state.localStreams[devId].getTracks().forEach(function (t) { t.stop(); });
                        delete state.localStreams[devId];
                    }
                    delete state.localLabels[devId];
                    var idx = state.slotMapping.indexOf(localId);
                    if (idx !== -1) state.slotMapping.splice(idx, 1);
                    changed = true;
                }
            }

            // Add new cameras
            for (var k = 0; k < videoDevices.length; k++) {
                var device = videoDevices[k];
                if (device.label && /integrated/i.test(device.label)) continue;
                var slotId = 'local-' + device.deviceId;
                if (state.slotMapping.includes(slotId)) continue;
                try {
                    var stream = await navigator.mediaDevices.getUserMedia({
                        video: { deviceId: { exact: device.deviceId } }
                    });
                    state.localStreams[device.deviceId] = stream;
                    state.localLabels[device.deviceId] = device.label || 'Local Camera';
                    state.slotMapping.push(slotId);
                    changed = true;
                } catch (err) {
                    console.warn('Local camera access failed:', device.label || device.deviceId, err);
                }
            }

            if (changed) renderAllSlots();
        } catch (err) {
            console.warn('enumerateDevices failed:', err);
        }
    }

    async function initLocalCameras() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            console.warn('getUserMedia not available — local cameras disabled');
            return;
        }

        // Request a throwaway stream to unlock device labels
        try {
            var tempStream = await navigator.mediaDevices.getUserMedia({ video: true });
            tempStream.getTracks().forEach(function (t) { t.stop(); });
        } catch (e) {
            console.warn('Camera permission denied — local cameras disabled');
            return;
        }

        await refreshLocalCameras();
        navigator.mediaDevices.addEventListener('devicechange', function () {
            refreshLocalCameras();
        });
    }

    // ========== CLEANUP ==========
    window.addEventListener('beforeunload', () => {
        state.controllerConnected = false;
        state.gamepadId = null;

        if (state.cameraWs) {
            state.cameraWs.close();
        }

        Object.keys(state.localStreams).forEach(function (id) {
            state.localStreams[id].getTracks().forEach(function (t) { t.stop(); });
        });

        socket.disconnect();
    });

    // ========== INITIALIZATION ==========
    initLogger();
    const slotAddBtn = document.getElementById('cam-slot-add');
    const slotRemoveBtn = document.getElementById('cam-slot-remove');
    if (slotAddBtn) slotAddBtn.onclick = addSlot;
    if (slotRemoveBtn) slotRemoveBtn.onclick = removeSlot;
    syncSlotControls();
    initCameraGrid();
    connectCamera();
    initLocalCameras();

    console.log('Controller input backend: Python pygame/SDL');

})();
