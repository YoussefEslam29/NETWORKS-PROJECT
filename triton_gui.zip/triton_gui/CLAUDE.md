# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build & Run

```bash
# One-time workspace build (run from ~/ros2_ws or the workspace root containing this package)
source /opt/ros/jazzy/setup.bash
colcon build --packages-select triton_gui
source install/setup.bash

# Run the pilot node
ros2 run triton_gui pilot_node

# Optional flags
ros2 run triton_gui pilot_node --arabic    # Arabic TTS audio
ros2 run triton_gui pilot_node --no-oak    # Disable OAK-D stereo camera

# Override default port (5050)
TRITON_GUI_PORT=8080 ros2 run triton_gui pilot_node
```

After `colcon build`, Flask serves templates and static files from the **installed share directory** (`install/triton_gui/share/triton_gui/`), not from the source tree. Any changes to `triton_gui/app/templates/` or `triton_gui/app/static/` require a rebuild to take effect.

## Architecture

The system is a ROS 2 node that hosts a Flask/Socket.IO web server. The browser communicates exclusively via Socket.IO (long-polling, not websockets — `allow_upgrades=False`).

### Data flow

```
ROS 2 topics/services  →  TritonGUINode (node.py)  →  socketio.emit()  →  Browser JS
Browser JS  →  socket.emit()  →  @socketio.on() handlers in node.py  →  ROS 2 services/publishers
```

### Key files

| File | Role |
|---|---|
| `triton_gui/node.py` | ROS 2 node + all Socket.IO event handlers. Owns robot state (arm, mode, gain, heartbeat). Publishes `Twist` on `movement/cmd_vel` at 5 Hz from a fixed-rate timer regardless of gamepad input. |
| `triton_gui/app/__init__.py` | Creates the Flask `app` and `socketio` singletons used everywhere. |
| `triton_gui/app/routes.py` | HTTP routes (page renders, TTS serving, SSH/PTY Socket.IO handlers, stereo camera routes). |
| `triton_gui/app/templates/index.html` | Pilot view — full-screen camera grid + status bar. Loads `gamepad.js` which owns controller input. |
| `triton_gui/app/templates/dashboard.html` | Dashboard view — sidebar nav with sections rendered via Jinja `{% include '_sec_*.html' %}`. |
| `triton_gui/app/static/js/dashboard.js` | **Must load first** — creates `window._appSocket`. Owns navigation, header pills, ROS log drawer, arm/mode/power display, confirm dialog. |
| `triton_gui/app/static/js/gamepad.js` | Browser Gamepad API polling + keyboard overlay. Emits `gamepad_state` to server. In dashboard mode (`window._dashboardMode`), sets `GamepadManager.noEmit = true` so input is display-only. |

### Dashboard sections

Each `_sec_*.html` partial has a corresponding JS file. The JS files attach to `window._appSocket` (created by `dashboard.js`). Sections and their JS:

| Section (`data-section`) | Partial | JS file |
|---|---|---|
| telemetry + graphs | `_sec_telemetry.html` + `_sec_graphs.html` | `system_telemetry.js`, `graphs.js` |
| diagnostics | `_sec_diagnostics.html` | `diagnostics.js` |
| config | `_sec_config.html` | `configuration.js` |
| gamepad | `_sec_gamepad.html` | `gamepad_diag.js` |
| ssh | `_sec_ssh.html` | `ssh_terminal.js` |
| stereo | `_sec_stereo.html` | `stereo.js` |
| tasks | `_sec_tasks.html` | `tasks.js` |
| cameras | `_sec_cameras.html` | `cameras.js` |
| system | inline in `dashboard.html` | handled in `dashboard.js` |
| firmware | `_sec_firmware.html` | `firmware.js` |

### Gamepad/controller ownership

The server enforces a single **pilot** via `__pilot_sid`. Only the first browser tab that emits `gamepad_connected` becomes the pilot; subsequent tabs receive the mapping but their `gamepad_state` events are ignored.

### ROS topics consumed

| Topic | Message type | Purpose |
|---|---|---|
| `movement/status` | `equinox_movement_types/Status` | Arm, mode, gain, depth, orientation, calibration |
| `power/status` | `equinox_power_types/PowerStatus` | ESC currents, buck voltages/temps |
| `safety/status` | `equinox_safety_types/SafetyStatus` | Internal pressure |
| `system/stats/rpicontrol` | `pi_system_types/Stats` | FCU CPU/RAM/temp |
| `system/stats/rpivision` | `pi_system_types/Stats` | Vision unit CPU/RAM/temp |
| `heartbeat` | `misc_types/Heartbeat` | Liveness for FCU (`node_id='equinox'`) and vision unit (`node_id='vision'`) |
| `rosout` | `rcl_interfaces/Log` | Streamed to ROS log drawer in dashboard |

### ROS services called

| Service | Type | When |
|---|---|---|
| `movement/set_state` | `equinox_movement_types/SetState` | Arm/disarm, mode change, gain change, calibrations |
| `movement/motor_test` | `equinox_movement_types/MotorTest` | From diagnostics section |
| `config/set` | `equinox_config_types/SetParameter` | From configuration section |
| `config/query` | `equinox_config_types/QueryParameters` | From configuration section |
| `config/commit` | `equinox_config_types/CommitParameters` | From configuration section |

### Per-device gamepad mappings

Mappings are stored as JSON in `~/.config/triton_gui/mappings/<device_id>.json`. The `DEFAULT_MAPPING` dict in `node.py` is the fallback.

### SSH terminal

`routes.py` spawns a real PTY (`/bin/bash --login`) per browser socket session using `pty.openpty()`. Sessions are keyed by Socket.IO `sid` and cleaned up on disconnect.
