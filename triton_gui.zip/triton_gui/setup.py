from setuptools import find_packages, setup
from glob import glob
import os

package_name = 'triton_gui'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/templates', glob('triton_gui/app/templates/*')),
        ('share/' + package_name + '/static/css', glob('triton_gui/app/static/css/*')),
        ('share/' + package_name + '/static/js', [f for f in glob('triton_gui/app/static/js/*') if os.path.isfile(f)]),
        ('share/' + package_name + '/static/js/vendor', glob('triton_gui/app/static/js/vendor/*')),
        ('share/' + package_name + '/tts-lines', glob('tts-lines/*.wav')),
        ('share/' + package_name + '/tts-lines-ar', glob('tts-lines-ar/*.wav')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='adham-waheeb',
    maintainer_email='adhamwaheeb4444@gmail.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'pilot_node = triton_gui.node:main',
            'test_pub = triton_gui.test_pub:main',
        ],
    },
)
