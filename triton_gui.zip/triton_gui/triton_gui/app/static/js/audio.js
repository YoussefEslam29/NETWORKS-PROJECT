(function () {
    'use strict';

    const AUDIO_FILES = {
        armed:                   'armed.wav',
        disarmed:                'disarmed.wav',
        controller_connected:    'controller_connected.wav',
        controller_disconnected: 'controller_disconnected.wav',
        fcu_online:              'flight_controller_online.wav',
        fcu_lost:                'flight_controller_lost.wav',
        welcome:                 'welcome_back_captain.wav',
        five_percent:            'five_percent.wav',
        ten_percent:             'ten_percent.wav',
        fifteen_percent:         'fifteen_percent.wav',
        twenty_percent:          'twenty_percent.wav',
        twenty_five_percent:     'twenty_five_percent.wav',
        thirty_percent:          'thirty_percent.wav',
        thirty_five_percent:     'thirty_five_percent.wav',
        forty_percent:           'forty_percent.wav',
        forty_five_percent:      'forty_five_percent.wav',
        fifty_percent:           'fifty_percent.wav',
        fifty_five_percent:      'fifty_five_percent.wav',
        sixty_percent:           'sixty_percent.wav',
        sixty_five_percent:      'sixty_five_percent.wav',
        seventy_percent:         'seventy_percent.wav',
        seventy_five_percent:    'seventy_five_percent.wav',
        eighty_percent:          'eighty_percent.wav',
        eighty_five_percent:     'eighty_five_percent.wav',
        ninety_percent:          'ninety_percent.wav',
        ninety_five_percent:     'ninety_five_percent.wav',
        one_hundred_percent:     'one_hundred_percent.wav',
        manual:                  'manual.wav',
        stabilise:               'stabilise.wav',
        depth_hold:              'depth_hold.wav',
        position_hold:           'position_hold.wav',
        pressure_warning:        'pressure_warning.wav',
        error:                   'error.wav',
        ten_minutes_remaining:   'ten_minutes_remaining.wav',
        five_minutes_remaining:  'five_minutes_remaining.wav',
        time_up:                 'time_up.wav',
    };

    const _el = new Audio();
    _el.preload = 'none';
    let _readyAt = 0;
    let _lang = 'en';

    fetch('/tts/language').then(function (r) { return r.json(); }).then(function (d) {
        if (d.lang) _lang = d.lang;
    }).catch(function () {});

    document.addEventListener('visibilitychange', function () {
        if (document.hidden) { _el.pause(); }
    });

    function play(key, opts) {
        const file = AUDIO_FILES[key];
        if (!file) return;
        if (!(opts && opts.force) && Date.now() < _readyAt) return;
        if (document.hidden) return;
        _el.pause();
        _el.src = '/tts/' + _lang + '/' + file;
        _el.load();
        _el.play().catch(function () {});
    }

    function holdFor(ms) {
        _readyAt = Date.now() + ms;
    }

    function setLang(lang) {
        if (lang === 'en' || lang === 'ar') _lang = lang;
    }

    window.tritonAudio = { play: play, holdFor: holdFor, setLang: setLang };
})();
