(function () {
    'use strict';

    const MOTION_AXES = ['surge', 'sway', 'heave', 'yaw', 'pitch', 'roll'];

    const ACTION_LABELS = {
        surge:              'Surge',
        sway:               'Sway',
        heave:              'Heave',
        yaw:                'Yaw',
        pitch:              'Pitch',
        roll:               'Roll',
        arm_disarm:         'Arm/Disarm',
        mode_manual:        'Manual',
        mode_stabilize:     'Stabilize',
        mode_depth_hold:    'Depth Hold',
        mode_position_hold: 'Position Hold',
        gripper_left:       'Gripper Left',
        gripper_right:      'Gripper Right',
        gain_up:            'Gain ↑',
        gain_down:          'Gain ↓',
        roll_cw:            'Roll CW',
        roll_ccw:           'Roll CCW',
    };

    // ── Socket ───────────────────────────────────────────────────────────────
    // Expose as window._appSocket so GamepadManager can find it on this page.
    const socket = window._appSocket || (window._appSocket = io({ transports: ['polling'] }));

    // ── State ────────────────────────────────────────────────────────────────
    let currentMapping = null;
    let learnTarget    = null;  // { type, name, el, learnBtn }


    // ── Compute motion output from raw gamepad + mapping + keyboard ───────────
    function computeMotion(axisName, axes, buttons, mapping, kbdContrib) {
        if (!mapping) return 0;
        const cfg      = (mapping.axes || {})[axisName] || {};
        const source   = cfg.source || 'axis';
        const deadzone = mapping.deadzone || 0.1;
        const invert   = cfg.invert || false;
        let val = 0;

        if (source === 'buttons') {
            const posIdx = cfg.pos != null ? cfg.pos : -1;
            const negIdx = cfg.neg != null ? cfg.neg : -1;
            const pos = posIdx >= 0 && posIdx < buttons.length ? buttons[posIdx] : 0;
            const neg = negIdx >= 0 && negIdx < buttons.length ? buttons[negIdx] : 0;
            val = (pos ? 1.0 : 0.0) - (neg ? 1.0 : 0.0);
        } else {
            const idx = cfg.index != null ? cfg.index : -1;
            if (idx >= 0 && idx < axes.length) {
                val = axes[idx];
                if (Math.abs(val) < deadzone) val = 0;
            }
        }

        const gpVal  = invert ? -val : val;
        const kbdVal = kbdContrib && kbdContrib.kbd_axes ? (kbdContrib.kbd_axes[axisName] || 0) : 0;
        return Math.max(-1, Math.min(1, gpVal + kbdVal));
    }

    // ── Motion output display ─────────────────────────────────────────────────
    function updateMotionDisplay(axes, buttons, kbdContrib) {
        MOTION_AXES.forEach(name => {
            const v    = computeMotion(name, axes, buttons, currentMapping, kbdContrib);
            const bar  = document.getElementById(`motion-bar-${name}`);
            const val  = document.getElementById(`motion-val-${name}`);
            if (!bar || !val) return;

            // Bar: 50% = centre. Positive extends right, negative extends left.
            if (v >= 0) {
                bar.style.left  = '50%';
                bar.style.width = `${v * 50}%`;
                bar.classList.remove('negative');
            } else {
                const w = Math.abs(v) * 50;
                bar.style.left  = `${50 - w}%`;
                bar.style.width = `${w}%`;
                bar.classList.add('negative');
            }

            val.textContent = v.toFixed(4);
            val.style.color = Math.abs(v) > 0.01 ? (v > 0 ? 'var(--blue)' : 'var(--orange)') : 'var(--text-muted)';
        });
    }

    // ── Active commands chips ─────────────────────────────────────────────────
    function buildActionChips() {
        const container = document.getElementById('active-actions');
        if (!container || !currentMapping) return;
        container.innerHTML = '';

        MOTION_AXES.forEach(function (name) {
            const chip = document.createElement('div');
            chip.className    = 'action-chip axis-chip';
            chip.dataset.action = name;
            chip.textContent  = ACTION_LABELS[name] || name;
            container.appendChild(chip);
        });

        const sep = document.createElement('div');
        sep.className = 'action-chip-sep';
        container.appendChild(sep);

        Object.keys(currentMapping.buttons || {}).forEach(function (name) {
            const chip = document.createElement('div');
            chip.className    = 'action-chip btn-chip';
            chip.dataset.action = name;
            chip.textContent  = ACTION_LABELS[name] || name;
            container.appendChild(chip);
        });
    }

    function updateActiveActions(axes, buttons, kbdContrib) {
        const container = document.getElementById('active-actions');
        if (!container || !currentMapping) return;

        MOTION_AXES.forEach(function (name) {
            const chip = container.querySelector(`[data-action="${name}"]`);
            if (!chip) return;
            const val = computeMotion(name, axes, buttons, currentMapping, kbdContrib);
            chip.classList.toggle('active', Math.abs(val) > 0);
        });

        Object.entries(currentMapping.buttons || {}).forEach(function ([name, cfg]) {
            const chip = container.querySelector(`[data-action="${name}"]`);
            if (!chip) return;
            let gpActive;
            if (typeof cfg === 'object' && cfg !== null && cfg.source === 'axis') {
                const idx = cfg.index != null ? cfg.index : -1;
                const thr = cfg.threshold != null ? cfg.threshold : 0.5;
                const dir = cfg.direction || 'positive';
                const v   = (idx >= 0 && idx < axes.length) ? axes[idx] : 0;
                gpActive = dir === 'negative' ? v < -thr : dir === 'any' ? Math.abs(v) > thr : v > thr;
            } else {
                const idx = typeof cfg === 'number' ? cfg : -1;
                gpActive = idx >= 0 && idx < buttons.length && buttons[idx] === 1;
            }
            const kbdActive = !!(kbdContrib && kbdContrib.kbd_buttons && kbdContrib.kbd_buttons[name]);
            chip.classList.toggle('active', gpActive || kbdActive);
        });
    }

    // ── Raw axis table ────────────────────────────────────────────────────────
    function buildAxisTable(axes) {
        const tbody = document.getElementById('axis-table-body');
        if (!tbody) return;
        if (tbody.children.length !== axes.length) {
            tbody.innerHTML = '';
            axes.forEach((_, i) => {
                const tr = document.createElement('tr');
                tr.innerHTML =
                    `<td class="axis-idx">${i}</td>` +
                    `<td><div class="axis-bar-wrap">` +
                        `<div class="axis-bar-fill" id="raw-bar-${i}"></div>` +
                        `<div class="axis-bar-center"></div>` +
                    `</div></td>` +
                    `<td class="axis-raw-val" id="raw-val-${i}">0.0000</td>`;
                tbody.appendChild(tr);
            });
        }
        axes.forEach((v, i) => {
            const fill = document.getElementById(`raw-bar-${i}`);
            const cell = document.getElementById(`raw-val-${i}`);
            if (!fill || !cell) return;
            fill.style.left  = v >= 0 ? '50%'            : `${((v + 1) / 2) * 100}%`;
            fill.style.width = v >= 0 ? `${v * 50}%`     : `${Math.abs(v) * 50}%`;
            cell.textContent = v.toFixed(4);
            cell.style.color = Math.abs(v) > 0.02 ? 'var(--text-primary)' : 'var(--text-muted)';
        });
    }

    // ── Button grid ──────────────────────────────────────────────────────────
    function buildButtonGrid(buttons) {
        const grid = document.getElementById('btn-grid');
        if (!grid) return;
        if (grid.children.length !== buttons.length) {
            grid.innerHTML = '';
            buttons.forEach((_, i) => {
                const d = document.createElement('div');
                d.className = 'btn-cell';
                d.id = `btn-cell-${i}`;
                d.textContent = i;
                grid.appendChild(d);
            });
        }
        buttons.forEach((v, i) => {
            const cell = document.getElementById(`btn-cell-${i}`);
            if (cell) cell.classList.toggle('pressed', v === 1);
        });
    }

    // ── GamepadManager callback ───────────────────────────────────────────────
    if (window.GamepadManager) {
        GamepadManager.onStateChange = function (axes, buttons, id, kbdContrib) {
            updateMotionDisplay(axes, buttons, kbdContrib || {});
            updateActiveActions(axes, buttons, kbdContrib || {});
            buildAxisTable(axes);
            buildButtonGrid(buttons);
            processLearnInput(axes, buttons);
        };

        // Keyboard hold checkbox.
        const kbdHoldChk = document.getElementById('kbd-hold-chk');
        if (kbdHoldChk) {
            const saved = localStorage.getItem('triton_kbd_hold');
            if (saved === 'true') {
                kbdHoldChk.checked = true;
                GamepadManager.kbdHold = true;
            }
            kbdHoldChk.addEventListener('change', function () {
                GamepadManager.kbdHold = kbdHoldChk.checked;
                localStorage.setItem('triton_kbd_hold', kbdHoldChk.checked);
            });
        }

        GamepadManager.start();
    }

    // ── Controller status ─────────────────────────────────────────────────────
    const banner     = document.getElementById('gp-status-banner');
    const bannerName = document.getElementById('gp-status-name');

    socket.on('controller_status', function (data) {
        if (!banner || !bannerName) return;
        banner.className = 'status-banner ' + (data.connected ? 'connected' : 'disconnected');
        bannerName.textContent = data.connected ? (data.name || 'Unknown controller') : 'No controller connected';
    });

    // ── Mapping ──────────────────────────────────────────────────────────────
    socket.on('mapping', function (data) {
        currentMapping = data;
        window._tritonMapping = data;   // share with gamepad.js for keyboard contrib
        populateMappingForm(data);
        buildActionChips();
    });

    socket.on('mapping_saved', function (data) {
        setStatus(data.ok ? 'Mapping saved.' : 'Save failed: ' + (data.error || '?'), data.ok ? 'ok' : 'error');
    });

    // ── Profile list ─────────────────────────────────────────────────────────
    socket.on('profiles_list', function (data) {
        const profiles = data.profiles || [];
        const sel = document.getElementById('profile-select');
        if (!sel) return;
        const current = activeProfile();
        sel.innerHTML = '';
        profiles.forEach(function (name) {
            const opt = document.createElement('option');
            opt.value = opt.textContent = name;
            if (name === current) opt.selected = true;
            sel.appendChild(opt);
        });
        // If server resolved to a different profile (e.g. stale localStorage) sync it.
        if (sel.value && sel.value !== current) {
            window.GamepadManager && window.GamepadManager.setActiveProfile(sel.value);
        }
    });

    // ── Device info + profile init ────────────────────────────────────────────
    (function initDeviceInfo() {
        const gm = window.GamepadManager;
        if (!gm) return;

        const idEl  = document.getElementById('device-id-display');
        const selEl = document.getElementById('profile-select');
        const newEl = document.getElementById('profile-new');
        const delEl = document.getElementById('profile-delete');

        const deviceId = gm.getDeviceId();
        if (idEl) idEl.textContent = deviceId;

        // Request profile list then current mapping.
        socket.emit('get_profiles', { device_id: deviceId });
        socket.emit('get_mapping', { device_id: deviceId, profile_name: activeProfile() });

        // Profile selector change — load the selected profile's mapping.
        if (selEl) {
            selEl.addEventListener('change', function () {
                const name = selEl.value;
                window.GamepadManager && window.GamepadManager.setActiveProfile(name);
                socket.emit('get_mapping', { device_id: deviceId, profile_name: name });
            });
        }

        // New Profile button.
        if (newEl) {
            newEl.addEventListener('click', function () {
                const name = prompt('New profile name:');
                if (!name || !name.trim()) return;
                socket.emit('create_profile', {
                    device_id:    deviceId,
                    profile_name: name.trim(),
                    copy_from:    activeProfile(),
                });
                // After server responds with profiles_list, switch to new profile.
                socket.once('profiles_list', function () {
                    const sel = document.getElementById('profile-select');
                    if (sel && sel.querySelector(`option[value="${CSS.escape(name.trim())}"]`)) {
                        window.GamepadManager && window.GamepadManager.setActiveProfile(name.trim());
                        sel.value = name.trim();
                        socket.emit('get_mapping', { device_id: deviceId, profile_name: name.trim() });
                    }
                });
            });
        }

        // Delete Profile button.
        if (delEl) {
            delEl.addEventListener('click', function () {
                const current = activeProfile();
                if (!confirm('Delete profile "' + current + '"?')) return;
                socket.emit('delete_profile', { device_id: deviceId, profile_name: current });
                // After list updates, switch to whatever is first.
                socket.once('profiles_list', function (data) {
                    const first = (data.profiles || ['Default'])[0];
                    window.GamepadManager && window.GamepadManager.setActiveProfile(first);
                    socket.emit('get_mapping', { device_id: deviceId, profile_name: first });
                });
            });
        }
    })();

    // ── Source select change ──────────────────────────────────────────────────
    function applySourceToRow(row, source) {
        row.dataset.source = source;
        // CSS rules handle show/hide via data-source attribute — nothing else needed.
    }

    document.querySelectorAll('.source-select').forEach(function (sel) {
        sel.addEventListener('change', function () {
            applySourceToRow(this.closest('tr'), this.value);
        });
    });

    function applyBtnSourceToRow(row, source) {
        row.dataset.btnSource = source;
        // CSS rules handle show/hide via data-btn-source attribute.
    }

    document.querySelectorAll('.btn-src-select').forEach(function (sel) {
        sel.addEventListener('change', function () {
            applyBtnSourceToRow(this.closest('tr'), this.value);
        });
    });

    // ── Keyboard binding editor ───────────────────────────────────────────────
    const AXIS_ACTIONS   = ['surge', 'sway', 'heave', 'yaw', 'pitch', 'roll'];
    const BUTTON_ACTIONS = [
        ['arm_disarm', 'Arm/Disarm'], ['mode_manual', 'Manual'],
        ['mode_stabilize', 'Stabilize'], ['mode_depth_hold', 'Depth Hold'],
        ['mode_position_hold', 'Position Hold'],
        ['gripper_left', 'Gripper Left'], ['gripper_right', 'Gripper Right'],
        ['gain_up', 'Gain ↑'], ['gain_down', 'Gain ↓'],
        ['roll_cw', 'Roll CW'], ['roll_ccw', 'Roll CCW'],
    ];
    const ALL_KBD_ACTIONS = [
        ...AXIS_ACTIONS.map(k => [k, ACTION_LABELS[k] || k]),
        ...BUTTON_ACTIONS,
    ];

    function _fmtKey(code) {
        if (!code) return '—';
        return code
            .replace(/^Key([A-Z])$/, '$1')
            .replace(/^Digit(\d)$/, '$1')
            .replace('ArrowUp', '↑').replace('ArrowDown', '↓')
            .replace('ArrowLeft', '←').replace('ArrowRight', '→');
    }

    function _actionOptions(selectedAction, type) {
        const actions = type === 'axis'
            ? AXIS_ACTIONS.map(k => [k, ACTION_LABELS[k] || k])
            : type === 'button' ? BUTTON_ACTIONS : ALL_KBD_ACTIONS;
        return actions.map(function ([k, label]) {
            return `<option value="${k}"${k === selectedAction ? ' selected' : ''}>${label}</option>`;
        }).join('');
    }

    let _kbdLearnRow = null;

    function _startKbdLearn(tr) {
        if (_kbdLearnRow) { _kbdLearnRow.classList.remove('learning-key'); }
        _kbdLearnRow = tr;
        tr.classList.add('learning-key');
        setStatus('Press any key to bind…', 'info');
    }

    // Capture in the capture phase so learn mode intercepts before other handlers.
    document.addEventListener('keydown', function (e) {
        if (!_kbdLearnRow) return;
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' ||
            e.target.tagName === 'SELECT') return;
        e.preventDefault();
        const code  = e.code;
        const badge = _kbdLearnRow.querySelector('.key-badge');
        if (badge) badge.textContent = _fmtKey(code);
        _kbdLearnRow.dataset.kbdCode = code;
        _kbdLearnRow.classList.remove('learning-key');
        _kbdLearnRow = null;
        setStatus(`Key "${code}" bound.`, 'ok');
    }, true);

    function _addKbdRow(code, type, action, value) {
        const tbody = document.getElementById('kbd-table-body');
        if (!tbody) return;
        const isAxis = type === 'axis';
        const tr = document.createElement('tr');
        tr.className    = 'kbd-row';
        tr.dataset.kbdCode = code || '';
        tr.innerHTML =
            `<td><span class="key-badge">${_fmtKey(code)}</span>` +
                `<button type="button" class="learn-btn kbd-key-learn">Learn</button></td>` +
            `<td><select class="kbd-type-select">` +
                `<option value="axis"${isAxis ? ' selected' : ''}>Axis</option>` +
                `<option value="button"${!isAxis ? ' selected' : ''}>Button</option>` +
            `</select></td>` +
            `<td><select class="kbd-action-select">${_actionOptions(action, type)}</select></td>` +
            `<td class="kbd-value-cell"${!isAxis ? ' style="display:none"' : ''}>` +
                `<input type="number" class="kbd-value-input" value="${value != null ? value : 1}" min="-1" max="1" step="0.1">` +
            `</td>` +
            `<td><button type="button" class="learn-btn kbd-remove-btn">✕</button></td>`;

        tr.querySelector('.kbd-type-select').addEventListener('change', function () {
            const t   = this.value;
            const sel = tr.querySelector('.kbd-action-select');
            sel.innerHTML = _actionOptions(sel.value, t);
            tr.querySelector('.kbd-value-cell').style.display = t === 'axis' ? '' : 'none';
        });

        tbody.appendChild(tr);
    }

    const addKbdBtn  = document.getElementById('add-kbd-binding-btn');
    const kbdTbody   = document.getElementById('kbd-table-body');

    if (addKbdBtn) addKbdBtn.addEventListener('click', function () {
        _addKbdRow('', 'axis', 'surge', 1.0);
    });

    if (kbdTbody) kbdTbody.addEventListener('click', function (e) {
        const learnBtn  = e.target.closest('.kbd-key-learn');
        const removeBtn = e.target.closest('.kbd-remove-btn');
        if (learnBtn)  { const row = learnBtn.closest('.kbd-row');  if (row) _startKbdLearn(row); }
        if (removeBtn) { const row = removeBtn.closest('.kbd-row'); if (row) row.remove(); }
    });

    // ── Populate form from mapping ────────────────────────────────────────────
    function populateMappingForm(mapping) {
        if (!mapping) return;

        const dz = document.getElementById('deadzone-input');
        if (dz) dz.value = mapping.deadzone != null ? mapping.deadzone : 0.1;

        // Axes
        Object.entries(mapping.axes || {}).forEach(function ([name, cfg]) {
            const row = document.querySelector(`[data-axis-name="${name}"]`);
            if (!row) return;
            const source = cfg.source || 'axis';
            const sel    = row.querySelector('.source-select');
            if (sel) sel.value = source;
            applySourceToRow(row, source);

            if (source === 'axis') {
                const idx = row.querySelector('.axis-index-input');
                if (idx) idx.value = cfg.index != null ? cfg.index : -1;
            } else {
                const pos = row.querySelector('.axis-pos-input');
                const neg = row.querySelector('.axis-neg-input');
                if (pos) pos.value = cfg.pos != null ? cfg.pos : -1;
                if (neg) neg.value = cfg.neg != null ? cfg.neg : -1;
            }
            const inv = row.querySelector('.axis-invert-check');
            if (inv) inv.checked = cfg.invert || false;
        });

        // Buttons
        Object.entries(mapping.buttons || {}).forEach(function ([name, cfg]) {
            const row = document.querySelector(`[data-btn-name="${name}"]`);
            if (!row) return;
            if (typeof cfg === 'object' && cfg !== null && cfg.source === 'axis') {
                const srcSel = row.querySelector('.btn-src-select');
                if (srcSel) { srcSel.value = 'axis'; applyBtnSourceToRow(row, 'axis'); }
                const idxEl = row.querySelector('.btn-axis-index-input');
                const thrEl = row.querySelector('.btn-threshold-input');
                const dirEl = row.querySelector('.btn-direction-select');
                if (idxEl) idxEl.value = cfg.index != null ? cfg.index : -1;
                if (thrEl) thrEl.value = cfg.threshold != null ? cfg.threshold : 0.5;
                if (dirEl) dirEl.value = cfg.direction || 'positive';
            } else {
                const srcSel = row.querySelector('.btn-src-select');
                if (srcSel) { srcSel.value = 'button'; applyBtnSourceToRow(row, 'button'); }
                const input = row.querySelector('.btn-index-input');
                if (input) input.value = typeof cfg === 'number' ? cfg : -1;
            }
        });

        // Keyboard bindings
        if (kbdTbody) {
            kbdTbody.innerHTML = '';
            Object.entries(mapping.keyboard || {}).forEach(function ([code, binding]) {
                _addKbdRow(code, binding.type || 'axis', binding.action || 'surge',
                           binding.value != null ? binding.value : 1.0);
            });
        }
    }

    // ── Collect form → mapping object ─────────────────────────────────────────
    function collectMapping() {
        const dz = document.getElementById('deadzone-input');
        const mapping = {
            deadzone: parseFloat(dz ? dz.value : 0.1) || 0.1,
            axes:    {},
            buttons: {},
        };

        document.querySelectorAll('[data-axis-name]').forEach(function (row) {
            const name   = row.dataset.axisName;
            const source = (row.querySelector('.source-select') || {}).value || 'axis';
            const invert = row.querySelector('.axis-invert-check') ? row.querySelector('.axis-invert-check').checked : false;

            if (source === 'axis') {
                const idxEl = row.querySelector('.axis-index-input');
                mapping.axes[name] = { source: 'axis', index: parseInt(idxEl ? idxEl.value : -1, 10), invert };
            } else {
                const posEl = row.querySelector('.axis-pos-input');
                const negEl = row.querySelector('.axis-neg-input');
                mapping.axes[name] = {
                    source: 'buttons',
                    pos: parseInt(posEl ? posEl.value : -1, 10),
                    neg: parseInt(negEl ? negEl.value : -1, 10),
                    invert,
                };
            }
        });

        document.querySelectorAll('[data-btn-name]').forEach(function (row) {
            const name   = row.dataset.btnName;
            const srcSel = row.querySelector('.btn-src-select');
            const src    = srcSel ? srcSel.value : 'button';
            if (src === 'axis') {
                const idxEl = row.querySelector('.btn-axis-index-input');
                const thrEl = row.querySelector('.btn-threshold-input');
                const dirEl = row.querySelector('.btn-direction-select');
                mapping.buttons[name] = {
                    source:    'axis',
                    index:     parseInt(idxEl ? idxEl.value : -1, 10),
                    threshold: parseFloat(thrEl ? thrEl.value : 0.5),
                    direction: dirEl ? dirEl.value : 'positive',
                };
            } else {
                const idxEl = row.querySelector('.btn-index-input');
                mapping.buttons[name] = parseInt(idxEl ? idxEl.value : -1, 10);
            }
        });

        // Keyboard bindings
        const keyboard = {};
        document.querySelectorAll('.kbd-row').forEach(function (row) {
            const code   = row.dataset.kbdCode;
            if (!code) return;
            const type   = (row.querySelector('.kbd-type-select')   || {}).value || 'axis';
            const action = (row.querySelector('.kbd-action-select') || {}).value || '';
            if (!action) return;
            const entry = { type, action };
            if (type === 'axis') {
                const v = parseFloat((row.querySelector('.kbd-value-input') || {}).value);
                entry.value = isNaN(v) ? 1.0 : v;
            }
            keyboard[code] = entry;
        });
        mapping.keyboard = keyboard;

        return mapping;
    }

    // ── Save / Reset ──────────────────────────────────────────────────────────
    const saveBtn  = document.getElementById('save-mapping-btn');
    const resetBtn = document.getElementById('reset-mapping-btn');

    function deviceId() {
        return window.GamepadManager ? window.GamepadManager.getDeviceId() : '';
    }

    function activeProfile() {
        return window.GamepadManager ? (window.GamepadManager.getActiveProfile() || 'Default') : 'Default';
    }

    if (saveBtn) saveBtn.addEventListener('click', function () {
        socket.emit('save_mapping', {
            device_id:    deviceId(),
            profile_name: activeProfile(),
            mapping:      collectMapping(),
        });
    });

    if (resetBtn) resetBtn.addEventListener('click', function () {
        if (!confirm('Reset "' + activeProfile() + '" to factory defaults?')) return;
        socket.emit('delete_profile', { device_id: deviceId(), profile_name: activeProfile() });
        setTimeout(function () {
            window.GamepadManager && window.GamepadManager.setActiveProfile('Default');
            socket.emit('get_mapping', { device_id: deviceId(), profile_name: 'Default' });
        }, 300);
    });

    // ── Learn mode ────────────────────────────────────────────────────────────
    function enterLearnMode(type, name, row, btn) {
        cancelLearnMode();
        learnTarget = { type, name, el: row, learnBtn: btn };
        row.classList.add('learning');
        if (btn) btn.classList.add('active');
        const labels = { axis: 'Move a stick axis…', 'btn-pos': 'Press the + button…', 'btn-neg': 'Press the − button…', button: 'Press a button…', 'btn-axis': 'Move a trigger/axis…' };
        setStatus(labels[type] || 'Press input…', 'info');
    }

    function cancelLearnMode() {
        if (!learnTarget) return;
        if (learnTarget.el)      learnTarget.el.classList.remove('learning');
        if (learnTarget.learnBtn) learnTarget.learnBtn.classList.remove('active');
        learnTarget = null;
    }

    function processLearnInput(axes, buttons) {
        if (!learnTarget) return;

        if (learnTarget.type === 'axis') {
            let maxVal = 0.3, maxIdx = -1;
            axes.forEach(function (v, i) { if (Math.abs(v) > maxVal) { maxVal = Math.abs(v); maxIdx = i; } });
            if (maxIdx < 0) return;
            const inp = learnTarget.el.querySelector('.axis-index-input');
            if (inp) inp.value = maxIdx;
            setStatus(`Axis ${maxIdx} → ${learnTarget.name}`, 'ok');
            cancelLearnMode();

        } else if (learnTarget.type === 'btn-pos' || learnTarget.type === 'btn-neg') {
            const idx = buttons.findIndex(function (b) { return b === 1; });
            if (idx < 0) return;
            const cls = learnTarget.type === 'btn-pos' ? '.axis-pos-input' : '.axis-neg-input';
            const inp = learnTarget.el.querySelector(cls);
            if (inp) inp.value = idx;
            const label = learnTarget.type === 'btn-pos' ? '+' : '−';
            setStatus(`Button ${idx} → ${learnTarget.name} (${label})`, 'ok');
            cancelLearnMode();

        } else if (learnTarget.type === 'button') {
            const idx = buttons.findIndex(function (b) { return b === 1; });
            if (idx < 0) return;
            const inp = learnTarget.el.querySelector('.btn-index-input');
            if (inp) inp.value = idx;
            setStatus(`Button ${idx} → ${learnTarget.name}`, 'ok');
            cancelLearnMode();

        } else if (learnTarget.type === 'btn-axis') {
            let maxVal = 0.3, maxIdx = -1;
            axes.forEach(function (v, i) { if (Math.abs(v) > maxVal) { maxVal = Math.abs(v); maxIdx = i; } });
            if (maxIdx < 0) return;
            const inp = learnTarget.el.querySelector('.btn-axis-index-input');
            if (inp) inp.value = maxIdx;
            setStatus(`Axis ${maxIdx} → ${learnTarget.name}`, 'ok');
            cancelLearnMode();
        }
    }

    // Learn button click delegation
    const form = document.getElementById('mapping-form');
    if (form) {
        form.addEventListener('click', function (e) {
            const btn = e.target.closest('.learn-btn');
            if (!btn) return;
            const row = btn.closest('[data-axis-name], [data-btn-name]');
            if (!row) return;

            if (row.dataset.axisName) {
                const type = btn.dataset.learn || 'axis';   // 'axis' | 'btn-pos' | 'btn-neg'
                enterLearnMode(type, row.dataset.axisName, row, btn);
            } else if (row.dataset.btnName) {
                const type = btn.dataset.learn || 'button';  // 'button' or 'btn-axis'
                enterLearnMode(type, row.dataset.btnName, row, btn);
            }
        });
    }

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') cancelLearnMode();
    });

    // ── Helpers ───────────────────────────────────────────────────────────────
    function setStatus(msg, type) {
        const el = document.getElementById('mapping-status');
        if (!el) return;
        el.textContent = msg;
        el.className   = 'mapping-status ' + (type || '');
    }

})();
