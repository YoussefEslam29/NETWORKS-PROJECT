/**
 * GamepadManager — browser Gamepad API → Socket.IO bridge.
 *
 * Each browser is identified by a canvas-fingerprint hash stored in
 * localStorage under 'triton_device_id'. The active controller-mapping
 * profile name is stored under 'triton_active_profile'.
 *
 * Exposes window.GamepadManager:
 *   .start()                — begin polling (auto-called on DOMContentLoaded)
 *   .stop()                 — halt polling
 *   .onStateChange          — callback(axes, buttons, id) for diagnostics UI
 *   .getActiveGamepad()     — returns the raw Gamepad object or null
 *   .getDeviceId()          — returns this browser's canvas-fingerprint ID
 *   .getActiveProfile()     — returns currently selected profile name
 *   .setActiveProfile(name) — saves profile name to localStorage
 */
(function () {
    'use strict';

    const POLL_HZ          = 60;
    const POLL_INTERVAL_MS = 1000 / POLL_HZ;
    const LS_ID_KEY        = 'triton_device_id';
    const LS_PROFILE_KEY   = 'triton_active_profile';

    let _rafId               = null;
    let _lastPollTime        = 0;
    let _lastAxesSnapshot    = null;
    let _lastButtonsSnapshot = null;
    let _lastKbdSnapshot     = '{}{}';
    let _activeIndex         = -1;
    let _onStateChange       = null;

    // ── Keyboard tracking ─────────────────────────────────────────────────────
    const _heldKeys = new Set();
    document.addEventListener('keydown', function (e) {
        // Don't swallow keys typed into form fields.
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' ||
            e.target.tagName === 'SELECT') return;
        _heldKeys.add(e.code);
    });
    document.addEventListener('keyup', function (e) {
        _heldKeys.delete(e.code);
    });

    function _computeKeyboardContrib() {
        const mapping = window._tritonMapping;
        if (!mapping || !mapping.keyboard) return { kbd_axes: {}, kbd_buttons: {} };

        const kbd_axes    = {};
        const kbd_buttons = {};

        for (const [code, binding] of Object.entries(mapping.keyboard)) {
            if (!_heldKeys.has(code)) continue;
            if (binding.type === 'axis') {
                const prev = kbd_axes[binding.action] || 0;
                kbd_axes[binding.action] = Math.max(-1, Math.min(1, prev + (binding.value != null ? binding.value : 1.0)));
            } else if (binding.type === 'button') {
                kbd_buttons[binding.action] = true;
            }
        }

        return { kbd_axes, kbd_buttons };
    }

    // ── Device identity ──────────────────────────────────────────────────────
    function _canvasFingerprint() {
        try {
            const c = document.createElement('canvas');
            c.width = 200; c.height = 50;
            const ctx = c.getContext('2d');
            ctx.textBaseline = 'alphabetic';
            ctx.fillStyle = '#f0f';
            ctx.fillRect(125, 1, 62, 20);
            ctx.fillStyle = '#069';
            ctx.font = '11pt no-real-font-6119679';
            ctx.fillText('Triton.', 2, 15);
            ctx.fillStyle = 'rgba(102,204,0,0.3)';
            ctx.font = '18pt Arial';
            ctx.fillText('Triton.', 4, 45);
            return c.toDataURL();
        } catch (e) { return null; }
    }

    function _djb2(str) {
        let h = 5381;
        for (let i = 0; i < str.length; i++) h = (((h << 5) + h) ^ str.charCodeAt(i)) >>> 0;
        return h.toString(16).padStart(8, '0');
    }

    function _getDeviceId() {
        let id = localStorage.getItem(LS_ID_KEY);
        if (id) return id;
        const fp = _canvasFingerprint();
        id = fp ? ('cv-' + _djb2(fp)) : ('rn-' + _djb2(Math.random().toString() + Date.now()));
        localStorage.setItem(LS_ID_KEY, id);
        return id;
    }

    function _getActiveProfile() {
        return localStorage.getItem(LS_PROFILE_KEY) || 'Default';
    }

    function _setActiveProfile(name) {
        localStorage.setItem(LS_PROFILE_KEY, name || 'Default');
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    function _getSocket() { return window._appSocket || null; }

    function _pickGamepad() {
        const pads = navigator.getGamepads ? navigator.getGamepads() : [];
        if (_activeIndex >= 0 && pads[_activeIndex] && pads[_activeIndex].connected) {
            return pads[_activeIndex];
        }
        for (let i = 0; i < pads.length; i++) {
            if (pads[i] && pads[i].connected) return pads[i];
        }
        return null;
    }

    function _snapshotEquals(a, b) {
        if (!a || !b || a.length !== b.length) return false;
        for (let i = 0; i < a.length; i++) { if (a[i] !== b[i]) return false; }
        return true;
    }

    // ── Announce already-connected gamepad after socket is ready ─────────────
    // The browser never fires 'gamepadconnected' for pads that were already
    // plugged in before this page loaded. Retry until the socket exists and
    // is connected (it may be created after this script runs).
    function _announceExistingGamepad() {
        const pads = navigator.getGamepads ? navigator.getGamepads() : [];
        let pad = null;
        for (let i = 0; i < pads.length; i++) {
            if (pads[i] && pads[i].connected) { pad = pads[i]; break; }
        }
        if (!pad) return;
        _activeIndex = pad.index;

        function tryEmit() {
            const s = _getSocket();
            if (!s || !s.connected) return false;
            s.emit('gamepad_connected', {
                id: pad.id, index: pad.index,
                device_id: _getDeviceId(), profile_name: _getActiveProfile(),
            });
            return true;
        }

        if (!tryEmit()) {
            let attempts = 0;
            const iv = setInterval(function () {
                if (tryEmit() || ++attempts > 30) clearInterval(iv);
            }, 100);
        }
    }

    // ── Poll loop ─────────────────────────────────────────────────────────────
    function _poll(timestamp) {
        _rafId = requestAnimationFrame(_poll);
        if (timestamp - _lastPollTime < POLL_INTERVAL_MS) return;
        _lastPollTime = timestamp;

        const pad        = _pickGamepad();
        const kbdContrib = _computeKeyboardContrib();
        const kbdStr     = JSON.stringify(kbdContrib.kbd_axes) + JSON.stringify(kbdContrib.kbd_buttons);

        const axes    = pad ? Array.from(pad.axes).map(v => parseFloat(v.toFixed(4)))    : [];
        const buttons = pad ? Array.from(pad.buttons).map(b => b.pressed ? 1 : 0) : [];

        if (typeof _onStateChange === 'function') _onStateChange(axes, buttons, pad ? pad.id : '', kbdContrib);

        const hasKbdInput = kbdStr !== '{}{}';
        const unchanged =
            _snapshotEquals(axes,    _lastAxesSnapshot) &&
            _snapshotEquals(buttons, _lastButtonsSnapshot) &&
            kbdStr === _lastKbdSnapshot;
        if (unchanged && !(GamepadManager.kbdHold && hasKbdInput)) return;

        _lastAxesSnapshot    = axes;
        _lastButtonsSnapshot = buttons;
        _lastKbdSnapshot     = kbdStr;

        if (!GamepadManager.noEmit && !window._dashboardMode) {
            const sock = _getSocket();
            if (sock) sock.emit('gamepad_state', {
                id:      pad ? pad.id : '',
                axes,
                buttons,
                ...kbdContrib,
            });
        }
    }

    // ── Gamepad connect / disconnect ──────────────────────────────────────────
    function _onConnect(event) {
        const pad = event.gamepad;
        _activeIndex         = pad.index;
        _lastAxesSnapshot    = null;
        _lastButtonsSnapshot = null;

        const sock = _getSocket();
        if (sock) {
            sock.emit('gamepad_connected', {
                id:           pad.id,
                index:        pad.index,
                device_id:    _getDeviceId(),
                profile_name: _getActiveProfile(),
            });
        }
        console.info('[GamepadManager] connected:', pad.id, '| device:', _getDeviceId());
    }

    function _onDisconnect(event) {
        const pad = event.gamepad;
        if (pad.index !== _activeIndex) return;
        _activeIndex         = -1;
        _lastAxesSnapshot    = null;
        _lastButtonsSnapshot = null;

        const sock = _getSocket();
        if (sock) sock.emit('gamepad_disconnected', {});
        console.info('[GamepadManager] disconnected:', pad.id);
    }

    // ── Public API ────────────────────────────────────────────────────────────
    const GamepadManager = {
        start() {
            if (_rafId !== null) return;
            window.addEventListener('gamepadconnected',    _onConnect);
            window.addEventListener('gamepaddisconnected', _onDisconnect);
            _rafId = requestAnimationFrame(_poll);

            // Announce any gamepad that was already connected before this page loaded.
            // The browser fires no 'gamepadconnected' event for pre-existing gamepads.
            // Defer until the socket is connected so the emit is not lost.
            _announceExistingGamepad();
        },
        stop() {
            if (_rafId !== null) { cancelAnimationFrame(_rafId); _rafId = null; }
            window.removeEventListener('gamepadconnected',    _onConnect);
            window.removeEventListener('gamepaddisconnected', _onDisconnect);
        },
        getActiveGamepad()    { return _pickGamepad(); },
        getDeviceId()         { return _getDeviceId(); },
        getActiveProfile()    { return _getActiveProfile(); },
        setActiveProfile(n)   { _setActiveProfile(n); },
        set onStateChange(fn) { _onStateChange = typeof fn === 'function' ? fn : null; },
        get onStateChange()   { return _onStateChange; },
        noEmit:  false,  // set true on diag/config pages to suppress ROV commands
        kbdHold: false,  // when true, held keyboard keys emit every poll tick (not just on change)
    };

    window.GamepadManager = GamepadManager;

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => GamepadManager.start());
    } else {
        GamepadManager.start();
    }
})();
