(function() {
    'use strict';

    const CONFIG = {
        NOTIFICATION_DURATION: 2500,
        POWER_ACTION: { UP: 0, DOWN: 1, ABS: 2 },
        POWER_IGNORE_VALUE: 255,
        CAMERA_WS_PORT: 9999,
        CAMERA_RECONNECT_DELAY: 3000,
        MODE_NAMES: ['Manual', 'Stabilise', 'Depth Hold', 'Position Hold'],
        MAX_LOGS: 200,
        CAM_FILTERS: {
            day:   'brightness(1.15) contrast(1.6) saturate(1.4) hue-rotate(15deg)',
            night: 'brightness(1.4) contrast(2.0) saturate(0.9)'
        }
    };

    const LOG_LEVELS = ['DEBUG', 'INFO', 'WARN', 'ERROR'];
    const LOG_TITLES = {
        DEBUG: 'Debug Logs',
        INFO: 'Info Logs',
        WARN: 'Warning Logs',
        ERROR: 'Error Logs'
    };

    const TIMER_START = 15 * 60; // 15 minutes in seconds

    const state = {
        timer: TIMER_START,
        timerInterval: null,
        gamepadId: null,
        controllerConnected: false,
        cameraWs: null,
        cameraReconnectTimer: null,
        slotMapping: [],
        dragSourceIndex: null,
        lastFrames: {},
        pendingAction: null,
        activeLogLevel: 'INFO',
        logsByLevel: { DEBUG: [], INFO: [], WARN: [], ERROR: [] },
        lastPower: null,
        cameraVisualFilter: null,
        localStreams: {},
        localLabels: {}
    };

    const DOM = {
        notification: document.getElementById('notification'),
        notificationTitle: document.getElementById('notification-title'),
        notificationMessage: document.getElementById('notification-message'),
        controlBox: document.getElementById('control-box'),
        gripperLed1: document.getElementById('gripper-led-1'),
        gripperLed2: document.getElementById('gripper-led-2'),
        gyroHorizon: document.getElementById('gyro-horizon'),
        gyroHeadingValue: document.getElementById('gyro-heading-value'),
        depthValue: document.getElementById('depth-value'),
        timerLabel: document.getElementById('timer'),
        startBtn: document.getElementById('start'),
        pauseBtn: document.getElementById('pause'),
        resetBtn: document.getElementById('reset'),
        armBtn: document.getElementById('arm-btn'),
        modeBtns: document.querySelectorAll('.mode-btn'),
        powerInput: document.getElementById('power-input'),
        powerDownBtn: document.getElementById('power-down'),
        powerAbsBtn: document.getElementById('power-abs'),
        powerUpBtn: document.getElementById('power-up'),
        powerValueDisplay: document.getElementById('power-value'),
        powerValueBox: document.getElementById('power-value-box'),
        loggerSection: document.getElementById('logger-section'),
        loggerButtons: document.querySelectorAll('.logger-trigger'),
        loggerPanel: document.getElementById('logger-panel'),
        loggerMessages: document.getElementById('logger-messages'),
        loggerTitle: document.getElementById('logger-title'),
        loggerClose: document.getElementById('logger-close'),
        camVisBtns: document.querySelectorAll('.cam-vis-btn'),
        cameraGrid: document.getElementById('camera-grid')
    };

    const loggerCounts = {
        DEBUG: document.getElementById('logger-count-debug'),
        INFO: document.getElementById('logger-count-info'),
        WARN: document.getElementById('logger-count-warn'),
        ERROR: document.getElementById('logger-count-error')
    };

    const socket = window._appSocket = io({ transports: ['polling'] });

    const POWER_AUDIO = {
        5: 'five_percent', 10: 'ten_percent', 15: 'fifteen_percent',
        20: 'twenty_percent', 25: 'twenty_five_percent', 30: 'thirty_percent',
        35: 'thirty_five_percent', 40: 'forty_percent', 45: 'forty_five_percent',
        50: 'fifty_percent', 55: 'fifty_five_percent', 60: 'sixty_percent',
        65: 'sixty_five_percent', 70: 'seventy_percent', 75: 'seventy_five_percent',
        80: 'eighty_percent', 85: 'eighty_five_percent', 90: 'ninety_percent',
        95: 'ninety_five_percent', 100: 'one_hundred_percent'
    };
    const MODE_AUDIO = ['manual', 'stabilise', 'depth_hold', 'position_hold'];

    // ========== UTILITIES ==========
    function notify(title, message, type = 'error') {
        DOM.notificationTitle.textContent = title;
        DOM.notificationMessage.textContent = message;
        DOM.notification.classList.remove('error', 'success');
        DOM.notification.classList.add(type, 'show');
        setTimeout(() => DOM.notification.classList.remove('show'), CONFIG.NOTIFICATION_DURATION);
    }

    // ========== CAMERA VISUAL FILTER ==========
    function applyVisualFilter(key) {
        const deactivate = state.cameraVisualFilter === key;
        state.cameraVisualFilter = deactivate ? null : key;
        DOM.camVisBtns.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.filter === state.cameraVisualFilter);
        });
        const filterVal = state.cameraVisualFilter ? CONFIG.CAM_FILTERS[state.cameraVisualFilter] : '';
        document.querySelectorAll('.camera-feed').forEach(canvas => {
            canvas.style.filter = filterVal;
        });
    }

    function formatTime(seconds) {
        const m = Math.floor(seconds / 60);
        const s = seconds % 60;
        return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    }

    function safeFixed(value, decimals = 1) {
        return (typeof value === 'number') ? value.toFixed(decimals) : '—';
    }

    function clamp(value, min, max) {
        return Math.min(Math.max(value, min), max);
    }

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // ========== LOGGER ==========
    const hasLogger = !!DOM.loggerMessages;

    function closeLogger() {
        if (!DOM.loggerSection) return;
        DOM.loggerSection.classList.remove('active');
    }

    function renderLogPanel(level) {
        if (!DOM.loggerMessages) return;
        const logs = state.logsByLevel[level] || [];
        DOM.loggerMessages.innerHTML = '';

        if (!logs.length) {
            DOM.loggerMessages.innerHTML = '<div class="logger-empty">No logs yet...</div>';
            return;
        }

        logs.forEach((entry) => {
            const node = document.createElement('div');
            node.className = `log-entry ${entry.level}`;
            node.innerHTML = `
                <span class="log-timestamp">${entry.timestamp}</span>
                <span class="log-level">${entry.level}</span>
                <span class="log-message">${escapeHtml(entry.message)}</span>
            `;
            DOM.loggerMessages.appendChild(node);
        });

        DOM.loggerMessages.scrollTop = DOM.loggerMessages.scrollHeight;
    }

    function updateLoggerCount(level) {
        const countEl = loggerCounts[level];
        if (!countEl) return;
        const count = state.logsByLevel[level].length;
        countEl.textContent = count;
        countEl.classList.remove('has-debug', 'has-info', 'has-warnings', 'has-errors');
        if (count > 0) {
            if (level === 'DEBUG') countEl.classList.add('has-debug');
            if (level === 'INFO') countEl.classList.add('has-info');
            if (level === 'WARN') countEl.classList.add('has-warnings');
            if (level === 'ERROR') countEl.classList.add('has-errors');
        }
    }

    function setActiveLogLevel(level) {
        state.activeLogLevel = level;
        if (DOM.loggerTitle) DOM.loggerTitle.textContent = LOG_TITLES[level] || 'System Log';
        DOM.loggerButtons.forEach((btn) => {
            btn.classList.toggle('active', btn.dataset.level === level);
        });
        renderLogPanel(level);
    }

    function openLogger(level) {
        if (!DOM.loggerSection) return;
        const isActive = DOM.loggerSection.classList.contains('active');
        if (isActive && state.activeLogLevel === level) {
            closeLogger();
            return;
        }
        setActiveLogLevel(level);
        DOM.loggerSection.classList.add('active');
    }

    function addLogEntry(timestamp, level, message) {
        if (level === 'FATAL') return;
        const normalizedLevel = LOG_LEVELS.includes(level) ? level : 'INFO';
        const logList = state.logsByLevel[normalizedLevel];
        if (DOM.loggerMessages) {
            const emptyState = DOM.loggerMessages.querySelector('.logger-empty');
            if (emptyState) emptyState.remove();
        }

        logList.push({ timestamp, level: normalizedLevel, message });
        while (logList.length > CONFIG.MAX_LOGS) {
            logList.shift();
        }

        updateLoggerCount(normalizedLevel);

        if (DOM.loggerSection && DOM.loggerSection.classList.contains('active') && state.activeLogLevel === normalizedLevel) {
            renderLogPanel(normalizedLevel);
        }
    }

    function initLogger() {
        if (!hasLogger) return;
        DOM.loggerMessages.innerHTML = '<div class="logger-empty">No logs yet...</div>';
        DOM.loggerButtons.forEach((btn) => {
            btn.onclick = () => openLogger(btn.dataset.level);
        });
        if (DOM.loggerClose) DOM.loggerClose.onclick = (e) => {
            e.stopPropagation();
            closeLogger();
        };
        LOG_LEVELS.forEach((level) => updateLoggerCount(level));
    }

    // Browser Gamepad API path disabled.
    // Controller input now comes from Python via pygame/SDL for consistent wired/Bluetooth handling.

    // ========== SOCKET EVENT HANDLERS ==========
    socket.on('connect', () => {
        window.tritonAudio?.holdFor(1000);
        window.tritonAudio?.play('welcome', { force: true });
        socket.emit('get_mapping', {
            device_id:    window.GamepadManager ? window.GamepadManager.getDeviceId() : '',
            profile_name: window.GamepadManager ? (window.GamepadManager.getActiveProfile() || 'Default') : 'Default',
        });
        GamepadManager.kbdHold = localStorage.getItem('triton_kbd_hold') === 'true';
    });

    window.addEventListener('storage', function (e) {
        if (e.key === 'triton_kbd_hold') {
            GamepadManager.kbdHold = e.newValue === 'true';
        }
    });

    socket.on('mapping', (data) => {
        window._tritonMapping = data;
    });

    socket.on('tts_language_changed', (data) => {
        window.tritonAudio?.setLang(data.lang);
        window.tritonAudio?.play('welcome', { force: true });
    });

    socket.on('safety_alert', () => {
        window.tritonAudio?.play('pressure_warning');
    });

    socket.on('gripper_status', (data) => {
        DOM.gripperLed1?.classList.toggle('active', !!data.one);
        DOM.gripperLed2?.classList.toggle('active', !!data.two);
    });

    socket.on('notification', (data) => {
        notify(
            data.success ? 'Success' : `Error ${data.error_code}`,
            data.message,
            data.success ? 'success' : 'error'
        );
        if (!data.success) window.tritonAudio?.play('error');
    });

    socket.on('terminal_log', (data) => {
        addLogEntry(data.timestamp, data.level, data.message);
    });

    socket.on('controller_status', (data) => {
        const wasConnected = state.controllerConnected;
        state.controllerConnected = !!data.connected;
        state.gamepadId = data.name || null;

        DOM.controlBox.classList.toggle('connected', state.controllerConnected);

        if (state.controllerConnected && (!wasConnected || state.gamepadId !== data.name)) {
            notify('Controller', data.name || 'Connected', 'success');
            window.tritonAudio?.play('controller_connected');
        } else if (!state.controllerConnected && wasConnected) {
            notify('Controller', 'Disconnected', 'error');
            window.tritonAudio?.play('controller_disconnected');
        }
    });

    socket.on('flight_controller_status', (data) => {
        notify(
            data.connected ? 'Connected' : 'Disconnected',
            data.connected ? 'Flight Controller Online' : 'Flight Controller Lost!',
            data.connected ? 'success' : 'error'
        );
        window.tritonAudio?.play(data.connected ? 'fcu_online' : 'fcu_lost');
    });

    socket.on('vision_unit_status', (data) => {
        notify(
            data.connected ? 'Connected' : 'Disconnected',
            data.connected ? 'Vision Unit Online' : 'Vision Unit Lost!',
            data.connected ? 'success' : 'error'
        );
    });

    socket.on('rov_orientation', (data) => {
        const roll = (typeof data.roll_deg === 'number') ? data.roll_deg : 0;
        const pitch = (typeof data.pitch_deg === 'number') ? data.pitch_deg : 0;
        const yaw = (typeof data.yaw_deg === 'number') ? data.yaw_deg : 0;

        if (DOM.gyroHorizon) {
            const pitchOffset = clamp(pitch * 0.6, -16, 16);
            DOM.gyroHorizon.style.transform = `translateY(${pitchOffset}px) rotate(${-roll}deg)`;
        }

        if (DOM.gyroHeadingValue) {
            const heading = ((yaw % 360) + 360) % 360;
            DOM.gyroHeadingValue.textContent = `${String(Math.round(heading)).padStart(3, '0')}°`;
        }
    });

    socket.on('rov_depth', (data) => {
        DOM.depthValue.textContent = `${safeFixed(data.depth, 2)} m`;
    });

    socket.on('arm_state', (data) => {
        DOM.armBtn.classList.toggle('armed', data.armed);
        DOM.armBtn.classList.toggle('disarmed', !data.armed);
        DOM.armBtn.textContent = data.armed ? 'ARMED' : 'DISARMED';
        DOM.armBtn.setAttribute('aria-pressed', data.armed ? 'true' : 'false');
        notify(
            data.armed ? 'Armed' : 'Disarmed',
            data.armed ? 'ROV is now ARMED' : 'ROV is now DISARMED',
            data.armed ? 'success' : 'error'
        );
        window.tritonAudio?.play(data.armed ? 'armed' : 'disarmed');
    });

    DOM.modeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            socket.emit('set_movement_mode', { mode: parseInt(btn.dataset.mode, 10) });
        });
    });

    function setActiveMode(mode) {
        DOM.modeBtns.forEach(btn => btn.classList.toggle('active', parseInt(btn.dataset.mode, 10) === mode));
    }

    socket.on('movement_mode_state', (data) => {
        setActiveMode(data.mode);
        notify('Mode', CONFIG.MODE_NAMES[data.mode], 'success');
        window.tritonAudio?.play(MODE_AUDIO[data.mode]);
    });

    socket.on('motor_power', (data) => {
        DOM.powerValueDisplay.textContent = `${data.power}%`;
        if (DOM.powerValueBox) {
            DOM.powerValueBox.classList.remove('low', 'medium', 'high', 'max');
            if (data.power >= 90) DOM.powerValueBox.classList.add('max');
            else if (data.power >= 70) DOM.powerValueBox.classList.add('high');
            else if (data.power >= 40) DOM.powerValueBox.classList.add('medium');
            else DOM.powerValueBox.classList.add('low');
        }
        if (state.lastPower !== data.power && POWER_AUDIO[data.power]) {
            window.tritonAudio?.play(POWER_AUDIO[data.power]);
        }
        state.lastPower = data.power;
    });

    socket.on('cam_layout_request', () => {
        socket.emit('cam_layout_state', { slotMapping: state.slotMapping.slice(), localLabels: Object.assign({}, state.localLabels) });
    });

    socket.on('cam_layout_update', (data) => {
        if (Array.isArray(data.slotMapping)) {
            state.slotMapping = data.slotMapping;
            renderAllSlots();
        }
    });

    socket.on('cam_maximize', (data) => {
        const slot = document.getElementById(`cam-${data.slotIndex}`);
        if (slot && slot.classList.contains('online')) {
            slot.classList.add('fullscreen');
        }
    });

    socket.on('cam_minimize', (data) => {
        const slot = document.getElementById(`cam-${data.slotIndex}`);
        if (slot) slot.classList.remove('fullscreen');
    });

    socket.on('cam_remove_slot', (data) => {
        const index = data.slotIndex;
        if (index < 0 || index >= state.slotMapping.length || state.slotMapping.length <= 1) return;
        const removed = state.slotMapping.splice(index, 1)[0];
        if (isLocalCamera(removed)) {
            const devId = getLocalDeviceId(removed);
            if (state.localStreams[devId]) {
                state.localStreams[devId].getTracks().forEach(t => t.stop());
                delete state.localStreams[devId];
            }
            delete state.localLabels[devId];
        }
        renderAllSlots();
    });

    socket.on('disconnect', () => {
        state.controllerConnected = false;
        state.gamepadId = null;
        DOM.controlBox.classList.remove('connected');
    });

    DOM.camVisBtns.forEach(btn => {
        btn.onclick = () => applyVisualFilter(btn.dataset.filter);
    });

    // ========== TIMER ==========
    DOM.timerLabel.textContent = formatTime(state.timer);

    DOM.startBtn.onclick = () => {
        if (state.timerInterval) return;
        state.timerInterval = setInterval(() => {
            if (state.timer <= 0) {
                clearInterval(state.timerInterval);
                state.timerInterval = null;
                window.tritonAudio?.play('time_up');
                return;
            }
            state.timer--;
            DOM.timerLabel.textContent = formatTime(state.timer);
            if (state.timer === 600) window.tritonAudio?.play('ten_minutes_remaining');
            if (state.timer === 300) window.tritonAudio?.play('five_minutes_remaining');
        }, 1000);
    };

    DOM.pauseBtn.onclick = () => {
        clearInterval(state.timerInterval);
        state.timerInterval = null;
    };

    DOM.resetBtn.onclick = () => {
        clearInterval(state.timerInterval);
        state.timerInterval = null;
        state.timer = TIMER_START;
        DOM.timerLabel.textContent = formatTime(state.timer);
    };

    // ========== ARM ==========
    DOM.armBtn.onclick = () => {
        socket.emit('set_arm', { arm: !DOM.armBtn.classList.contains('armed') });
    };

    // ========== POWER ==========
    DOM.powerDownBtn.onclick = () => {
        socket.emit('set_motor_power', { action: CONFIG.POWER_ACTION.DOWN, power_abs_value: CONFIG.POWER_IGNORE_VALUE });
    };

    DOM.powerUpBtn.onclick = () => {
        socket.emit('set_motor_power', { action: CONFIG.POWER_ACTION.UP, power_abs_value: CONFIG.POWER_IGNORE_VALUE });
    };

    DOM.powerAbsBtn.onclick = () => {
        const value = parseInt(DOM.powerInput.value, 10);
        if (isNaN(value)) {
            notify('Input Error', 'Power value must be a valid number', 'error');
            return;
        }
        socket.emit('set_motor_power', { action: CONFIG.POWER_ACTION.ABS, power_abs_value: value });
    };

    // ========== GAMEPAD ==========
    // Browser polling and navigator.getGamepads() are intentionally disabled.
    // Python publishes controller status and consumes input directly.

    // ========== KEYBOARD UI SHORTCUTS ==========
    document.addEventListener('keydown', (e) => {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
        if (e.key === 'Escape') {
            closeLogger();
            document.querySelectorAll('.camera-slot.fullscreen').forEach(s => {
                const slotIndex = parseInt(s.id.replace('cam-', ''));
                socket.emit('cam_minimize', { slotIndex });
                s.classList.remove('fullscreen');
            });
            if (document.fullscreenElement) document.exitFullscreen();
        }
        if (e.key === 'f' || e.key === 'F') {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen();
            } else {
                document.exitFullscreen();
            }
        }
    });

    document.addEventListener('fullscreenchange', () => {
        if (!document.fullscreenElement) {
            document.querySelectorAll('.camera-slot.fullscreen').forEach(s => {
                const slotIndex = parseInt(s.id.replace('cam-', ''));
                socket.emit('cam_minimize', { slotIndex });
                s.classList.remove('fullscreen');
            });
        }
    });

    document.addEventListener('click', (e) => {
        // Close logger when clicking outside
        if (DOM.loggerSection && !DOM.loggerSection.contains(e.target)) {
            closeLogger();
        }
    });

    // ========== LOCAL CAMERA HELPERS ==========
    function isLocalCamera(id) {
        return typeof id === 'string' && id.startsWith('local-');
    }

    function getLocalDeviceId(slotId) {
        return slotId.slice(6);
    }

    // ========== SLOT CONTROLS ==========
    function syncSlotControls() {
        const removeBtn = document.getElementById('cam-slot-remove');
        if (removeBtn) removeBtn.disabled = state.slotMapping.length <= 1;
    }

    function addSlot() {
        const intIds = state.slotMapping.filter(id => typeof id === 'number');
        const nextId = intIds.length > 0 ? Math.max(...intIds) + 1 : 0;
        state.slotMapping.push(nextId);
        renderAllSlots();
    }

    function removeSlot() {
        if (state.slotMapping.length <= 1) return;
        const removed = state.slotMapping[state.slotMapping.length - 1];
        state.slotMapping.pop();
        if (isLocalCamera(removed)) {
            const devId = getLocalDeviceId(removed);
            if (state.localStreams[devId]) {
                state.localStreams[devId].getTracks().forEach(t => t.stop());
                delete state.localStreams[devId];
            }
            delete state.localLabels[devId];
        }
        renderAllSlots();
    }

    // ========== CAMERA GRID ==========
    function drawFrameToCanvas(canvas, jpegBytes) {
        const blob = new Blob([jpegBytes], { type: 'image/jpeg' });
        return createImageBitmap(blob).then((bitmap) => {
            canvas.width  = bitmap.width;
            canvas.height = bitmap.height;
            canvas.getContext('2d').drawImage(bitmap, 0, 0);
            bitmap.close();
        });
    }

    function createSlotElement(index) {
        const cameraId = state.slotMapping[index];
        const isLocal = isLocalCamera(cameraId);
        const slot = document.createElement('div');
        slot.className = 'camera-slot offline';
        slot.id = `cam-${index}`;
        slot.draggable = true;

        if (isLocal) {
            const deviceId = getLocalDeviceId(cameraId);
            const label = state.localLabels[deviceId] || 'Local Camera';
            slot.innerHTML =
                `<div class="camera-label">${label}</div>` +
                `<video class="camera-feed" id="feed-${index}" autoplay playsinline muted></video>` +
                `<div class="camera-offline">OFFLINE</div>`;
        } else {
            slot.innerHTML =
                `<div class="camera-label">Camera ${cameraId}</div>` +
                `<canvas class="camera-feed" id="feed-${index}"></canvas>` +
                `<div class="camera-offline">OFFLINE</div>`;
        }

        const canvas = slot.querySelector('.camera-feed');
        if (state.cameraVisualFilter) canvas.style.filter = CONFIG.CAM_FILTERS[state.cameraVisualFilter];

        // Per-slot remove button (bottom-right, only when >1 slot)
        if (state.slotMapping.length > 1) {
            const removeBtn = document.createElement('button');
            removeBtn.className = 'cam-slot-remove';
            removeBtn.textContent = '\u00d7';
            removeBtn.title = 'Remove camera';
            removeBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                if (state.slotMapping.length <= 1) return;
                const removed = state.slotMapping.splice(index, 1)[0];
                if (isLocalCamera(removed)) {
                    const devId = getLocalDeviceId(removed);
                    if (state.localStreams[devId]) {
                        state.localStreams[devId].getTracks().forEach(t => t.stop());
                        delete state.localStreams[devId];
                    }
                    delete state.localLabels[devId];
                }
                renderAllSlots();
            });
            slot.appendChild(removeBtn);
        }

        // Fullscreen click
        slot.addEventListener('click', (e) => {
            if (!slot.classList.contains('fullscreen') && slot.classList.contains('online')) {
                slot.classList.add('fullscreen');
                socket.emit('cam_maximize', { slotIndex: index });
            }
        });

        // Drag events
        slot.addEventListener('dragstart', () => {
            state.dragSourceIndex = index;
            slot.classList.add('dragging');
        });

        slot.addEventListener('dragend', () => {
            slot.classList.remove('dragging');
            state.dragSourceIndex = null;
        });

        slot.addEventListener('dragover', (e) => {
            e.preventDefault();
            slot.classList.add('drag-over');
        });

        slot.addEventListener('dragleave', () => {
            slot.classList.remove('drag-over');
        });

        slot.addEventListener('drop', (e) => {
            e.preventDefault();
            slot.classList.remove('drag-over');
            const from = state.dragSourceIndex;
            const to = index;
            if (from !== null && from !== to) {
                const temp = state.slotMapping[from];
                state.slotMapping[from] = state.slotMapping[to];
                state.slotMapping[to] = temp;
                renderAllSlots();
            }
        });

        return slot;
    }

    function updateGridColumns() {
        const count = state.slotMapping.length;
        let cols;
        if (count <= 1) cols = '1fr';
        else if (count <= 4) cols = '1fr 1fr';
        else if (count <= 6) cols = '1fr 1fr 1fr';
        else cols = 'repeat(auto-fill, minmax(300px, 1fr))';
        DOM.cameraGrid.style.gridTemplateColumns = cols;
    }

    function renderAllSlots() {
        DOM.cameraGrid.querySelectorAll('.camera-slot').forEach(el => el.remove());

        for (let i = 0; i < state.slotMapping.length; i++) {
            const slotEl = createSlotElement(i);
            DOM.cameraGrid.appendChild(slotEl);

            const cameraId = state.slotMapping[i];
            if (isLocalCamera(cameraId)) {
                const deviceId = getLocalDeviceId(cameraId);
                const video = slotEl.querySelector('.camera-feed');
                if (video && state.localStreams[deviceId]) {
                    video.srcObject = state.localStreams[deviceId];
                    slotEl.classList.add('online');
                    slotEl.classList.remove('offline');
                }
            } else {
                const canvas = slotEl.querySelector('.camera-feed');
                if (canvas && state.lastFrames[cameraId]) {
                    drawFrameToCanvas(canvas, state.lastFrames[cameraId]).then(() => {
                        slotEl.classList.add('online');
                        slotEl.classList.remove('offline');
                    }).catch(() => {});
                }
            }
        }

        updateGridColumns();
        socket.emit('cam_layout_state', { slotMapping: state.slotMapping.slice(), localLabels: Object.assign({}, state.localLabels) });
        syncSlotControls();
    }

    function initCameraGrid() {
        state.slotMapping = [];
        renderAllSlots();
    }

    // ========== CAMERA STREAM ==========
    function connectCamera() {
        const wsUrl = `ws://${window.location.hostname}:${CONFIG.CAMERA_WS_PORT}`;

        try {
            state.cameraWs = new WebSocket(wsUrl);
            state.cameraWs.binaryType = 'arraybuffer';

            state.cameraWs.onopen = () => {
                notify('Cameras', 'Stream connected', 'success');
                if (state.cameraReconnectTimer) {
                    clearTimeout(state.cameraReconnectTimer);
                    state.cameraReconnectTimer = null;
                }
            };

            state.cameraWs.onclose = () => {
                state.lastFrames = {};
                for (let i = 0; i < state.slotMapping.length; i++) {
                    if (isLocalCamera(state.slotMapping[i])) continue;
                    const slot = document.getElementById(`cam-${i}`);
                    if (slot) {
                        slot.classList.remove('online');
                        slot.classList.add('offline');
                    }
                }
                scheduleCameraReconnect();
            };

            state.cameraWs.onerror = (err) => console.error('Camera error:', err);

            state.cameraWs.onmessage = (e) => {
                if (!(e.data instanceof ArrayBuffer)) return;
                const buf = e.data;
                const view = new DataView(buf);
                let offset = 0;
                const numCams = view.getUint8(offset++);

                const thisFrames = {};
                let slotsChanged = false;
                for (let i = 0; i < numCams; i++) {
                    const camId = view.getUint8(offset++);
                    const jpegSize = view.getUint32(offset, true); offset += 4;
                    const jpegBytes = new Uint8Array(buf, offset, jpegSize); offset += jpegSize;
                    thisFrames[camId] = jpegBytes;
                    state.lastFrames[camId] = jpegBytes;
                    if (!state.slotMapping.includes(camId)) {
                        state.slotMapping.push(camId);
                        slotsChanged = true;
                    }
                }

                if (slotsChanged) renderAllSlots();

                for (let i = 0; i < state.slotMapping.length; i++) {
                    const camId = state.slotMapping[i];
                    if (isLocalCamera(camId)) continue;
                    const slot = document.getElementById(`cam-${i}`);
                    const canvas = document.getElementById(`feed-${i}`);
                    if (thisFrames[camId] && slot && canvas) {
                        drawFrameToCanvas(canvas, thisFrames[camId]).then(() => {
                            slot.classList.add('online');
                            slot.classList.remove('offline');
                        }).catch(() => {});
                    }
                }
            };
        } catch (err) {
            console.error('Camera connection failed:', err);
            scheduleCameraReconnect();
        }
    }

    function scheduleCameraReconnect() {
        if (state.cameraReconnectTimer) return;
        state.cameraReconnectTimer = setTimeout(() => {
            state.cameraReconnectTimer = null;
            connectCamera();
        }, CONFIG.CAMERA_RECONNECT_DELAY);
    }

    // ========== LOCAL CAMERAS ==========
    async function refreshLocalCameras() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return;

        try {
            const devices = await navigator.mediaDevices.enumerateDevices();
            const videoDevices = devices.filter(function (d) { return d.kind === 'videoinput'; });
            const activeDeviceIds = new Set(videoDevices.map(function (d) { return d.deviceId; }));
            let changed = false;

            // Remove unplugged cameras
            var currentLocal = state.slotMapping.filter(isLocalCamera);
            for (var j = 0; j < currentLocal.length; j++) {
                var localId = currentLocal[j];
                var devId = getLocalDeviceId(localId);
                if (!activeDeviceIds.has(devId)) {
                    if (state.localStreams[devId]) {
                        state.localStreams[devId].getTracks().forEach(function (t) { t.stop(); });
                        delete state.localStreams[devId];
                    }
                    delete state.localLabels[devId];
                    var idx = state.slotMapping.indexOf(localId);
                    if (idx !== -1) state.slotMapping.splice(idx, 1);
                    changed = true;
                }
            }

            // Add new cameras
            for (var k = 0; k < videoDevices.length; k++) {
                var device = videoDevices[k];
                if (device.label && /integrated/i.test(device.label)) continue;
                var slotId = 'local-' + device.deviceId;
                if (state.slotMapping.includes(slotId)) continue;
                try {
                    var stream = await navigator.mediaDevices.getUserMedia({
                        video: { deviceId: { exact: device.deviceId } }
                    });
                    state.localStreams[device.deviceId] = stream;
                    state.localLabels[device.deviceId] = device.label || 'Local Camera';
                    state.slotMapping.push(slotId);
                    changed = true;
                } catch (err) {
                    console.warn('Local camera access failed:', device.label || device.deviceId, err);
                }
            }

            if (changed) renderAllSlots();
        } catch (err) {
            console.warn('enumerateDevices failed:', err);
        }
    }

    async function initLocalCameras() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            console.warn('getUserMedia not available — local cameras disabled');
            return;
        }

        // Request a throwaway stream to unlock device labels
        try {
            var tempStream = await navigator.mediaDevices.getUserMedia({ video: true });
            tempStream.getTracks().forEach(function (t) { t.stop(); });
        } catch (e) {
            console.warn('Camera permission denied — local cameras disabled');
            return;
        }

        await refreshLocalCameras();
        navigator.mediaDevices.addEventListener('devicechange', function () {
            refreshLocalCameras();
        });
    }

    // ========== CLEANUP ==========
    window.addEventListener('beforeunload', () => {
        state.controllerConnected = false;
        state.gamepadId = null;

        if (state.cameraWs) {
            state.cameraWs.close();
        }

        Object.keys(state.localStreams).forEach(function (id) {
            state.localStreams[id].getTracks().forEach(function (t) { t.stop(); });
        });

        socket.disconnect();
    });

    // ========== INITIALIZATION ==========
    initLogger();
    const slotAddBtn = document.getElementById('cam-slot-add');
    const slotRemoveBtn = document.getElementById('cam-slot-remove');
    if (slotAddBtn) slotAddBtn.onclick = addSlot;
    if (slotRemoveBtn) slotRemoveBtn.onclick = removeSlot;
    syncSlotControls();
    initCameraGrid();
    connectCamera();
    initLocalCameras();

    console.log('Controller input backend: Python pygame/SDL');

})();
