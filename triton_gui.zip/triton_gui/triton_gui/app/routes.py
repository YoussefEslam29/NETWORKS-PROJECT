from triton_gui.app import app, socketio
from flask import render_template, send_from_directory, abort, request, jsonify
from ament_index_python.packages import get_package_share_directory
import pathlib
import os

_TTS_BASE = pathlib.Path(get_package_share_directory('triton_gui'))


@app.route('/tts/language', methods=['GET'])
def get_tts_language():
    return jsonify({'lang': app.config.get('TTS_LANG', 'en')})

@app.route('/tts/language', methods=['POST'])
def set_tts_language():
    lang = request.json.get('lang') if request.json else None
    if lang not in ('en', 'ar'):
        return jsonify({'error': 'invalid lang'}), 400
    app.config['TTS_LANG'] = lang
    socketio.emit('tts_language_changed', {'lang': lang})
    return jsonify({'lang': lang})

@app.route('/tts/<lang>/<path:filename>')
def serve_tts(lang, filename):
    if lang not in ('en', 'ar'):
        abort(404)
    tts_dir = _TTS_BASE / ('tts-lines-ar' if lang == 'ar' else 'tts-lines')
    if not tts_dir.is_dir():
        abort(404)
    return send_from_directory(str(tts_dir), filename)


@app.route('/')
def home_page():
    return render_template('index.html')

