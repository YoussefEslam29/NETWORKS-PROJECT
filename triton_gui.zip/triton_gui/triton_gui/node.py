import rclpy
from rclpy.node import Node
from rclpy.client import Client
from rclpy.qos import QoSProfile,QoSReliabilityPolicy,QoSHistoryPolicy,QoSDurabilityPolicy
import rclpy.logging
from triton_gui.app import app, socketio
from flask import request
from flask_socketio import emit
from rcl_interfaces.msg import Log

from equinox_movement_types.msg import Status
from equinox_movement_types.srv import SetState
from equinox_payload_types.msg import Payloads
from equinox_power_types.msg import PowerStatus
from equinox_safety_types.msg import SafetyStatus
from pi_system_types.msg import Stats
import subprocess
import psutil
from misc_types.msg import Heartbeat


from geometry_msgs.msg import Twist

from ament_index_python.packages import get_package_share_directory

import threading
import socket
import time
import json
import os
import sqlite3
from pathlib import Path

DEAD_THRESHOLD = 3

# SetState gain sentinels (as per SetState.srv comments)
_GAIN_UP   = 105
_GAIN_DOWN = 110

_DB_PATH = Path.home() / '.local' / 'share' / 'triton_gui' / 'controller_mappings.db'

DEFAULT_MAPPING ={
  "deadzone": 0.1,
  "axes": {
    "surge": {
      "source": "axis",
      "index": 1,
      "invert": True
    },
    "sway": {
      "source": "axis",
      "index": 0,
      "invert": False
    },
    "heave": {
      "source": "axis",
      "index": 3,
      "invert": True
    },
    "yaw": {
      "source": "axis",
      "index": 2,
      "invert": False
    },
    "pitch": {
      "source": "buttons",
      "pos": 12,
      "neg": 13,
      "invert": False
    },
    "roll": {
      "source": "buttons",
      "pos": 14,
      "neg": 15,
      "invert": True
    }
  },
  "buttons": {
    "arm_disarm": 0,
    "mode_manual": 2,
    "mode_stabilize": -1,
    "mode_depth_hold": -1,
    "mode_position_hold": -1,
    "gripper_left": 5,
    "gripper_right": 4,
    "gain_up": 9,
    "gain_down": 8,
    "roll_cw": 6,
    "roll_ccw": 7
  },
  "keyboard": {
  }
}


class TritonGUINode(Node):
    def __init__(self):
        super().__init__('gui')
        self.get_logger().set_level(rclpy.logging.LoggingSeverity.DEBUG)

        #initial attributes.
        self.__is_shutting_down = False
        self.__fcu_status = False
        self.__lastfcu_time = 0

        self.__visionu_status = False
        self.__lastvisionu_time = 0

        self.__arm_status = False

        self.__movement_mode = 0
        
        self.__motor_power = 0

        self.__pressure_normal = True

        self.__current_device_id = ''
        self.__current_profile   = 'Default'
        self.__mapping = self.__default_mapping()
        self.__prev_buttons = {}
        self.__controller_connected = False
        self.__controller_name = ''
        self.__pilot_sid = None
        self.__db_lock = threading.Lock()
        self.__init_db()

        self.__gripper_status = {
            'one': False,
            'two': False,
        }
        self.__last_payload_state = (False, False, False, False)


        #periodically calls the check inactivity.
        self.create_timer(0.5, self.__check_inactivity)

        #publish cmd_vel at a fixed 5 Hz.
        self.create_timer(0.2, self.__publish_cmd_vel)

        #local system telemetry (2 s interval).
        self.create_timer(2.0, self.__collect_local_stats)

        #rosout log.
        self.create_subscription(Log,
            'rosout',
            self.__log_callback,
            self.__qos_profile(10)
        )

        #vision and flight controller telemetry.
        self.create_subscription(Stats,
            'system/stats/rpicontrol',
            self.__flight_controller_telemetry,
            self.__qos_profile()
            )

        self.create_subscription(Stats,
            'system/stats/rpivision',
            self.__vision_unit_telemetry,
            self.__qos_profile()
            )            

        #flight controller readings.
        self.create_subscription(Status,
            'movement/status',
            self.__flight_controller_readings,
            self.__qos_profile()
        )

        #internal box safety.
        self.create_subscription(SafetyStatus,
            'safety/status',
            self.__internal_box_safety,
            self.__qos_profile())
        
        #esc and buck info.
        self.create_subscription(PowerStatus,
            'power/status',
            self.__buck_esc_readings,
            self.__qos_profile())

        #heartbeat liveness.
        self.create_subscription(Heartbeat,
            'heartbeat',
            self.__heartbeat_callback,
            self.__qos_profile())


        #set state client.
        self.__set_state_client = self.create_client(SetState,'movement/set_state')

        #controller input movement command publisher.
        self.__cmd_vel_pub = self.create_publisher(Twist,'movement/cmd_vel',self.__qos_profile(1))
        self.__twist = Twist()

        #grippers publisher.
        self.__grippers_pub = self.create_publisher(Payloads,'payload',self.__qos_profile(1))
        self.__grippers = Payloads()

        #background thread spin.
        self.__ros_thread = threading.Thread(target=self.__ros,daemon=True)
        self.__ros_thread.start()

        #socket events.
        self.__handle_socket_events()


    #rosout log callback function.
    def __log_callback(self,msg:Log):
        level_mapping = {
            Log.DEBUG: 'DEBUG',
            Log.INFO: 'INFO',
            Log.WARN: 'WARN',
            Log.ERROR: 'ERROR',
            Log.FATAL: 'FATAL',
        }

        level = level_mapping.get(msg.level, 'INFO')

        timestamp = f'{msg.stamp.sec}.{msg.stamp.nanosec // 1000000:03d}'
        
        socketio.emit('terminal_log',{
                'timestamp': timestamp,
                'level': level,
                'message': f'[{msg.name}] {msg.msg}',
            })
        

    #fcu telemetry callback function.
    def __flight_controller_telemetry(self,msg:Stats):
        socketio.emit('flight_controller_telemetry',{
            'cpu_usage': msg.cpu_usage,
            'cpu_temp': msg.cpu_temperature,
            'ram_usage': msg.ram_usage,
            'uptime': msg.uptime_s,
            'undervoltage': msg.undervoltage,
            'input_voltage': float(msg.input_voltage),
            'core_current_a': float(msg.core_current_a),
        })

        if msg.throttled:
            self.get_logger().warn('Flight controller throttling!')
            self.__emit_notification(False, -1, 'Flight controller throttling!')

    #vision unit telemetry callback function.
    def __vision_unit_telemetry(self,msg:Stats):
        socketio.emit('vision_unit_telemetry',{
            'cpu_usage': msg.cpu_usage,
            'cpu_temp': msg.cpu_temperature,
            'ram_usage': msg.ram_usage,
            'uptime': msg.uptime_s,
            'undervoltage': msg.undervoltage,
            'input_voltage': float(msg.input_voltage),
            'core_current_a': float(msg.core_current_a),
        })

        if msg.throttled:
            self.get_logger().warn('Vision unit throttling!')
            self.__emit_notification(False, -1, 'Vision unit throttling!')

    #local system stats collector (runs on a 2 s timer).
    def __collect_local_stats(self):
        cpu_usage = psutil.cpu_percent()

        cpu_temp = 0.0
        try:
            temps = psutil.sensors_temperatures()
            if 'cpu_thermal' in temps:
                cpu_temp = temps['cpu_thermal'][0].current
            elif 'coretemp' in temps:
                cpu_temp = temps['coretemp'][0].current
        except Exception:
            try:
                with open('/sys/class/thermal/thermal_zone0/temp') as f:
                    cpu_temp = int(f.read().strip()) / 1000.0
            except Exception:
                pass

        ram_usage = psutil.virtual_memory().percent
        uptime_s = int(time.time() - psutil.boot_time())

        undervoltage = False
        throttled = False
        try:
            out = subprocess.check_output(
                ['vcgencmd', 'get_throttled'], text=True, timeout=1
            )
            val = int(out.strip().split('=')[1], 16)
            undervoltage = bool(val & 0x1)   # bit 0: under-voltage detected
            throttled    = bool(val & 0x4)   # bit 2: currently throttled
        except Exception:
            pass

        socketio.emit('system_telemetry', {
            'cpu_usage':    cpu_usage,
            'cpu_temp':     cpu_temp,
            'ram_usage':    ram_usage,
            'uptime':       uptime_s,
            'undervoltage': undervoltage,
        })
        socketio.emit('system_status', {'connected': True})

        if throttled:
            self.get_logger().warn('Local system throttling!')

    #fcu readings callback function.
    def __flight_controller_readings(self,msg:Status):

        #arm/disarm.
        prev_arm_status = self.__arm_status
        self.__arm_status = msg.armed

        if self.__arm_status != prev_arm_status:
            socketio.emit('arm_state', {
                'armed': self.__arm_status
            })
            message = 'Armed' if self.__arm_status else 'Disarmed'
            self.get_logger().warn(f'Flight Controller: {message}')

        #movement mode.
        prev_movement_mode = self.__movement_mode
        self.__movement_mode = int(msg.movement_mode)

        if self.__movement_mode != prev_movement_mode:
            socketio.emit('movement_mode_state', {
                'mode': int(self.__movement_mode)
            })
            message = self.__movement_mode
            self.get_logger().warn(f'Flight Mode: {message}')

        #motor power.
        prev_motor_power = self.__motor_power
        self.__motor_power = int(msg.gain)

        if self.__motor_power != prev_motor_power:
            socketio.emit('motor_power',{
                'power' : int(self.__motor_power)
            })
            message = f'{self.__motor_power}%'
            self.get_logger().info(f'Motor power changed: {message}')

        #depth.
        socketio.emit('rov_depth',{
            'depth' : float(msg.depth)
        })
        self.get_logger().debug(f'ROV depth updated: {msg.depth}')

        #orientation.
        socketio.emit('rov_orientation', {
            'yaw_deg':   float(msg.euler.x),
            'roll_deg':  float(msg.euler.y),
            'pitch_deg': float(msg.euler.z),
        })
        #self.get_logger().debug(f'ROV orientation updated: roll={msg.euler.x}, pitch={msg.euler.y}, yaw={msg.euler.z}')

        #calibration values and system state.
        socketio.emit('rov_calibration', {
            'accelerometer': [int(i) for i in msg.accelerometer_calibration],
            'magnetometer': [int(i) for i in msg.magnetometer_calibration],
            'gyroscope': [int(i) for i in msg.gyroscope_calibration],
            'input_timeout': bool(msg.input_timeout),
            'motor_test_active': bool(msg.motor_test_active),
            'autotune_active': bool(msg.autotune_active),
            'imu_a_connected': bool(msg.imu_a_connected),
            'imu_b_connected': bool(msg.imu_b_connected),
            'depth_sensor_connected': bool(msg.depth_sensor_connected),
        })
        self.get_logger().debug(f'Calibration updated')

    #safety status callback function.
    def __internal_box_safety(self, msg: SafetyStatus):
        prev_pressure = self.__pressure_normal
        self.__pressure_normal = bool(msg.internal_pressure_normal)

        if self.__pressure_normal != prev_pressure:
            if not self.__pressure_normal:
                self.get_logger().error('Internal pressure abnormal!')
                self.__emit_notification(False, -1, 'Internal pressure abnormal')
                socketio.emit('safety_alert', {'abnormal': True})
            else:
                self.get_logger().info('Internal pressure normal')
                self.__emit_notification(True, 0, 'Internal pressure normal')
    
    #buck and esc readings callback function.
    def __buck_esc_readings(self, msg: PowerStatus):
        socketio.emit('power_stats', {
            'esc_currents': [float(i) for i in msg.motor_currents],

            'buck_a': {
                'voltage': float(msg.buck_a_voltage),
                'temperature': float(msg.buck_a_temp)
            },

            'buck_b': {
                'voltage': float(msg.buck_b_voltage),
                'temperature': float(msg.buck_b_temp)
            }
        })

    #heartbeat callback function.
    def __heartbeat_callback(self, msg: Heartbeat):
        if msg.node_id == 'equinox':
            self.__lastfcu_time = time.monotonic()
        elif msg.node_id == 'vision':
            self.__lastvisionu_time = time.monotonic()

    #handle socket events.
    def __handle_socket_events(self):

        #browser connection event.
        @socketio.on('connect')
        def handle_connect():
            emit('arm_state', {'armed': self.__arm_status})
            emit('movement_mode_state', {'mode': self.__movement_mode})
            emit('motor_power', {'power': self.__motor_power})
            emit('flight_controller_status', {'connected': self.__fcu_status})
            emit('vision_unit_status', {'connected': self.__visionu_status})
            emit('controller_status', {
                'connected': self.__controller_connected,
                'name': self.__controller_name
            })
            emit('mapping', self.__mapping)

        #clear pilot ownership when the pilot's browser disconnects.
        @socketio.on('disconnect')
        def handle_disconnect():
            if request.sid == self.__pilot_sid:
                self.__pilot_sid = None
                self.__controller_connected = False
                self.__controller_name = ''
                self.__prev_buttons = {}
                self.__apply_gamepad_state([], [])
                socketio.emit('controller_status', {'connected': False, 'name': ''})
                self.get_logger().info('Pilot disconnected')

        #gamepad_connected socket event.
        @socketio.on('gamepad_connected')
        def handle_gamepad_connected(data):
            name         = data.get('id', '')
            device_id    = data.get('device_id', '')
            profile_name = data.get('profile_name', 'Default')
            sid          = request.sid
            if self.__pilot_sid is not None and self.__pilot_sid != sid:
                emit('mapping', self.__mapping)
                return
            self.__pilot_sid = sid
            if device_id:
                profiles = self.__db_get_profiles(device_id)
                if not profiles:
                    self.__db_upsert(device_id, 'Default', self.__default_mapping())
                    profiles = ['Default']
                    profile_name = 'Default'
                elif profile_name not in profiles:
                    profile_name = profiles[0]
                self.__current_device_id = device_id
                self.__current_profile   = profile_name
                self.__mapping = self.__db_get_mapping(device_id, profile_name) or self.__default_mapping()
                self.__prev_buttons = {}
            self.__controller_connected = True
            self.__controller_name = name
            socketio.emit('controller_status', {'connected': True, 'name': name})
            emit('mapping', self.__mapping)
            self.get_logger().info(
                f'Browser gamepad connected: {name} (device={device_id or "unknown"}, profile={profile_name})'
            )

        #gamepad_disconnected socket event.
        @socketio.on('gamepad_disconnected')
        def handle_gamepad_disconnected(data=None):
            if request.sid != self.__pilot_sid:
                return
            self.__pilot_sid = None
            self.__controller_connected = False
            self.__controller_name = ''
            self.__prev_buttons = {}
            self.__apply_gamepad_state([], [])
            socketio.emit('controller_status', {'connected': False, 'name': ''})
            self.get_logger().info('Browser gamepad disconnected')

        #gamepad_state socket event.
        @socketio.on('gamepad_state')
        def handle_gamepad_state(data):
            if request.sid != self.__pilot_sid:
                return
            axes     = data.get('axes', [])
            buttons  = data.get('buttons', [])
            kbd_axes = data.get('kbd_axes', {})
            kbd_btns = data.get('kbd_buttons', {})
            self.__apply_gamepad_state(axes, buttons, kbd_axes, kbd_btns)

        @socketio.on('get_profiles')
        def handle_get_profiles(data=None):
            data = data or {}
            device_id = data.get('device_id', '')
            profiles = self.__db_get_profiles(device_id) or ['Default']
            emit('profiles_list', {'profiles': profiles})

        @socketio.on('get_mapping')
        def handle_get_mapping(data=None):
            data = data or {}
            device_id    = data.get('device_id', '')
            profile_name = data.get('profile_name', 'Default')
            mapping = self.__db_get_mapping(device_id, profile_name) or self.__default_mapping()
            emit('mapping', mapping)

        @socketio.on('save_mapping')
        def handle_save_mapping(data):
            device_id    = data.get('device_id', '')
            profile_name = data.get('profile_name', 'Default')
            mapping      = data.get('mapping')
            if mapping is None:
                self.__db_delete_profile(device_id, profile_name)
            else:
                self.__db_upsert(device_id, profile_name, mapping)
                if device_id == self.__current_device_id and profile_name == self.__current_profile:
                    self.__mapping = mapping
            emit('mapping_saved', {'ok': True})

        @socketio.on('create_profile')
        def handle_create_profile(data):
            device_id    = data.get('device_id', '')
            profile_name = (data.get('profile_name') or '').strip()
            copy_from    = data.get('copy_from', 'Default')
            if not profile_name:
                emit('profiles_list', {'profiles': self.__db_get_profiles(device_id) or ['Default'], 'error': 'empty name'})
                return
            base = self.__db_get_mapping(device_id, copy_from) or self.__default_mapping()
            self.__db_upsert(device_id, profile_name, base)
            emit('profiles_list', {'profiles': self.__db_get_profiles(device_id)})

        @socketio.on('delete_profile')
        def handle_delete_profile(data):
            device_id    = data.get('device_id', '')
            profile_name = data.get('profile_name', '')
            self.__db_delete_profile(device_id, profile_name)
            profiles = self.__db_get_profiles(device_id) or ['Default']
            emit('profiles_list', {'profiles': profiles})

        #arm/disarm socket event.
        @socketio.on('set_arm')
        def get_arm_value(data):
            arm = bool(data['arm'])
            if self.__arm_status == arm:
                return
            self.__set_state(self.__movement_mode, arm, self.__motor_power,
                             expected_arm=arm)

        #set movement mode socket event.
        @socketio.on('set_movement_mode')
        def get_movement_mode_value(data):
            mode = int(data['mode'])
            if self.__movement_mode == mode:
                return
            self.__set_state(mode, self.__arm_status, self.__motor_power,
                             expected_mode=mode)

        #motor power socket event. action: 0=UP 1=DOWN 2=ABS
        @socketio.on('set_motor_power')
        def get_power_action(data):
            action = int(data['action'])
            if action == 0:
                gain = _GAIN_UP
            elif action == 1:
                gain = _GAIN_DOWN
            else:
                gain = int(data['power_abs_value'])
            self.__set_state(self.__movement_mode, self.__arm_status, gain)

        #shutdown/restart socket event.
        @socketio.on('shutdown')
        def shutdown():
            self.__shutdown()



    #shutdown.
    def __shutdown(self):
        self.get_logger().info('System shutdown requested')
        self.__emit_notification(True, 0, 'System shutting down...')
        def _do():
            time.sleep(1.5)
            subprocess.run(['sudo', 'systemctl', 'poweroff'], check=False)
        threading.Thread(target=_do, daemon=True).start()

    #set state — unified service call for arm, mode, gain, and calibrations.
    def __set_state(self, mode: int, arm: bool, gain: int,
                    do_accelerometer_calibration: bool = False,
                    do_magnetometer_calibration: bool = False,
                    do_gyroscope_calibration: bool = False,
                    expected_arm=None, expected_mode=None):
        if not self.__check_service(self.__set_state_client):
            self.get_logger().error('Set State service unavailable!')
            self.__emit_notification(False, -1, 'Set State service unavailable!')
            return

        req = SetState.Request()
        req.mode = mode
        req.arm = arm
        req.gain = gain
        req.do_accelerometer_calibration = do_accelerometer_calibration
        req.do_magnetometer_calibration = do_magnetometer_calibration
        req.do_gyroscope_calibration = do_gyroscope_calibration
        future = self.__set_state_client.call_async(req)
        future.add_done_callback(
            lambda f: self.__handle_set_state_response(f, expected_arm, expected_mode)
        )

    def __handle_set_state_response(self, future, expected_arm=None, expected_mode=None):
        try:
            res = future.result()
            self.get_logger().info(
                f'Set State response: success={res.success}, gain={res.gain_value}, error={res.error_code}'
            )
            if res.success:
                self.__motor_power = int(res.gain_value)
                socketio.emit('motor_power', {'power': self.__motor_power})
                if expected_arm is not None:
                    self.__arm_status = expected_arm
                    socketio.emit('arm_state', {'armed': self.__arm_status})
                if expected_mode is not None:
                    self.__movement_mode = expected_mode
                    socketio.emit('movement_mode_state', {'mode': self.__movement_mode})
            self.__emit_notification(
                res.success, res.error_code,
                f'gain={res.gain_value}%' if res.success else f'Failed (error {res.error_code})'
            )
        except Exception as e:
            self.get_logger().error(f'Set State service call failed: {e}')
            self.__emit_notification(False, -1, f'Service call failed: {e}')

    #publish the current twist at a fixed rate.
    def __publish_cmd_vel(self):
        if self.__is_shutting_down:
            return
        try:
            self.__cmd_vel_pub.publish(self.__twist)
        except Exception as e:
            self.get_logger().error(f'Failed to publish twist: {e}')

    #apply incoming browser gamepad state.
    def __apply_gamepad_state(self, axes: list, buttons: list,
                               kbd_axes: dict = None, kbd_buttons: dict = None):
        if self.__is_shutting_down:
            return

        kbd_axes    = kbd_axes    or {}
        kbd_buttons = kbd_buttons or {}
        deadzone = self.__mapping.get('deadzone', 0.1)

        def get_axis(name):
            cfg = self.__mapping['axes'].get(name, {})
            source = cfg.get('source', 'axis')
            invert = cfg.get('invert', False)

            if source == 'buttons':
                pos_idx = cfg.get('pos', -1)
                neg_idx = cfg.get('neg', -1)
                pos = bool(buttons[pos_idx]) if 0 <= pos_idx < len(buttons) else False
                neg = bool(buttons[neg_idx]) if 0 <= neg_idx < len(buttons) else False
                val = (1.0 if pos else 0.0) - (1.0 if neg else 0.0)
            else:
                idx = cfg.get('index', -1)
                if idx < 0 or idx >= len(axes):
                    val = 0.0
                else:
                    val = float(axes[idx])
                    if abs(val) < deadzone:
                        val = 0.0

            gp_val = -val if invert else val
            # Merge keyboard axis contribution (additive, clamped).
            return max(-1.0, min(1.0, gp_val + float(kbd_axes.get(name, 0.0))))

        def _read_btn_cfg(cfg) -> bool:
            if isinstance(cfg, dict) and cfg.get('source') == 'axis':
                idx = cfg.get('index', -1)
                thr = float(cfg.get('threshold', 0.5))
                direction = cfg.get('direction', 'positive')
                if idx < 0 or idx >= len(axes):
                    return False
                v = float(axes[idx])
                if direction == 'negative':
                    return v < -thr
                if direction == 'any':
                    return abs(v) > thr
                return v > thr  # 'positive'
            idx = cfg if isinstance(cfg, int) else -1
            return bool(buttons[idx]) if 0 <= idx < len(buttons) else False

        def btn_pressed(name):
            cfg = self.__mapping['buttons'].get(name, -1)
            current  = _read_btn_cfg(cfg) or bool(kbd_buttons.get(name, False))
            previous = self.__prev_buttons.get(name, False)
            self.__prev_buttons[name] = current
            return current and not previous

        def btn_held(name):
            cfg = self.__mapping['buttons'].get(name, -1)
            return _read_btn_cfg(cfg) or bool(kbd_buttons.get(name, False))

        self.__twist.linear.y  = get_axis('surge')
        self.__twist.linear.x  = get_axis('sway')
        self.__twist.linear.z  = get_axis('heave')
        self.__twist.angular.x = get_axis('yaw')
        self.__twist.angular.z = get_axis('pitch')
        self.__twist.angular.y = get_axis('roll')


        if btn_pressed('arm_disarm'):
            new_arm = not self.__arm_status
            self.__set_state(self.__movement_mode, new_arm, self.__motor_power,
                             expected_arm=new_arm)

        if btn_pressed('mode_manual'):
            self.__set_state(0, self.__arm_status, self.__motor_power, expected_mode=0)

        if btn_pressed('mode_stabilize'):
            self.__set_state(1, self.__arm_status, self.__motor_power, expected_mode=1)

        if btn_pressed('mode_depth_hold'):
            self.__set_state(2, self.__arm_status, self.__motor_power, expected_mode=2)

        if btn_pressed('mode_position_hold'):
            self.__set_state(3, self.__arm_status, self.__motor_power, expected_mode=3)

        gripper_changed = False
        if btn_pressed('gripper_left'):
            self.__gripper_status['one'] = not self.__gripper_status['one']
            gripper_changed = True

        if btn_pressed('gripper_right'):
            self.__gripper_status['two'] = not self.__gripper_status['two']
            gripper_changed = True

        if gripper_changed:
            socketio.emit('gripper_status', self.__gripper_status)

        roll_cw_held  = btn_held('roll_cw')
        roll_ccw_held = btn_held('roll_ccw')

        payload_state = (
            self.__gripper_status['one'],
            self.__gripper_status['two'],
            roll_cw_held,
            roll_ccw_held,
        )

        if payload_state != self.__last_payload_state:
            self.__last_payload_state = payload_state
            self.__grippers.gripper1 = payload_state[0]
            self.__grippers.gripper2 = payload_state[1]
            self.__grippers.roll_clk = payload_state[2]
            self.__grippers.roll_anti = payload_state[3]
            try:
                self.__grippers_pub.publish(self.__grippers)
            except Exception as e:
                if not self.__is_shutting_down:
                    self.get_logger().error(f'Failed to publish payloads: {e}')

        if btn_pressed('gain_up'):
            self.__set_state(self.__movement_mode, self.__arm_status, _GAIN_UP)

        if btn_pressed('gain_down'):
            self.__set_state(self.__movement_mode, self.__arm_status, _GAIN_DOWN)
            
    #checks each unit's heartbeat.
    def __check_inactivity(self):
        now = time.monotonic()
        prev_fcu_status = self.__fcu_status
        prev_vu_status = self.__visionu_status

        self.__fcu_status = False if now - self.__lastfcu_time > DEAD_THRESHOLD else True

        if self.__fcu_status != prev_fcu_status:
            socketio.emit('flight_controller_status', {
                'connected': self.__fcu_status
            })
            message = 'Connected' if self.__fcu_status else 'Disconnected'
            self.get_logger().warn(f'Flight Controller: {message}')

        self.__visionu_status = False if now - self.__lastvisionu_time > DEAD_THRESHOLD else True

        if self.__visionu_status != prev_vu_status:
            socketio.emit('vision_unit_status', {
                'connected': self.__visionu_status
            })
            message = 'Connected' if self.__visionu_status else 'Disconnected'
            self.get_logger().warn(f'Vision Unit: {message}')

    #check service status.
    def __check_service(self, client:Client) -> bool:
        return client.service_is_ready()

    #qos profile factory.
    def __qos_profile(self,depth:int = 5) -> QoSProfile:
        return QoSProfile(
            reliability = QoSReliabilityPolicy.BEST_EFFORT,
            history = QoSHistoryPolicy.KEEP_LAST,
            durability = QoSDurabilityPolicy.VOLATILE,
            depth = depth
        )

    #build a fresh copy of the default mapping.
    def __default_mapping(self) -> dict:
        return {
            'deadzone': DEFAULT_MAPPING['deadzone'],
            'axes':    {k: dict(v) for k, v in DEFAULT_MAPPING['axes'].items()},
            'buttons': dict(DEFAULT_MAPPING['buttons']),
            'keyboard': dict(DEFAULT_MAPPING.get('keyboard', {})),
        }

    # ── SQLite helpers ─────────────────────────────────────────────────────────
    def __init_db(self):
        _DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        self.__db = sqlite3.connect(str(_DB_PATH), check_same_thread=False)
        self.__db.execute('''
            CREATE TABLE IF NOT EXISTS profiles (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                device_id    TEXT    NOT NULL,
                profile_name TEXT    NOT NULL DEFAULT 'Default',
                deadzone     REAL    NOT NULL DEFAULT 0.1,
                axes         TEXT    NOT NULL,
                buttons      TEXT    NOT NULL,
                keyboard     TEXT    NOT NULL DEFAULT '{}',
                updated_at   TEXT    NOT NULL DEFAULT (datetime('now')),
                UNIQUE(device_id, profile_name)
            )
        ''')
        self.__db.commit()

    def __db_get_profiles(self, device_id: str) -> list:
        with self.__db_lock:
            rows = self.__db.execute(
                'SELECT profile_name FROM profiles WHERE device_id=? ORDER BY id',
                (device_id,)
            ).fetchall()
        return [r[0] for r in rows]

    def __db_get_mapping(self, device_id: str, profile_name: str) -> dict | None:
        with self.__db_lock:
            row = self.__db.execute(
                'SELECT deadzone, axes, buttons, keyboard FROM profiles WHERE device_id=? AND profile_name=?',
                (device_id, profile_name)
            ).fetchone()
        if not row:
            return None
        try:
            return {
                'deadzone': row[0],
                'axes':     json.loads(row[1]),
                'buttons':  json.loads(row[2]),
                'keyboard': json.loads(row[3]),
            }
        except Exception:
            return None

    def __db_upsert(self, device_id: str, profile_name: str, mapping: dict):
        with self.__db_lock:
            self.__db.execute(
                '''INSERT OR REPLACE INTO profiles
                       (device_id, profile_name, deadzone, axes, buttons, keyboard, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, datetime('now'))''',
                (
                    device_id,
                    profile_name,
                    float(mapping.get('deadzone', 0.1)),
                    json.dumps(mapping.get('axes', {})),
                    json.dumps(mapping.get('buttons', {})),
                    json.dumps(mapping.get('keyboard', {})),
                )
            )
            self.__db.commit()

    def __db_delete_profile(self, device_id: str, profile_name: str):
        with self.__db_lock:
            self.__db.execute(
                'DELETE FROM profiles WHERE device_id=? AND profile_name=?',
                (device_id, profile_name)
            )
            self.__db.commit()

    #server ip.
    def __get_ip(self) -> str:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(('192.168.0.1', 1))
            return s.getsockname()[0]
        except OSError as e:
            self.get_logger().warn(f'Unable to determine LAN IP, falling back to localhost: {e}')
            return '127.0.0.1'
        finally:
            s.close()
    
    #notification helper.
    def __emit_notification(self, success: bool, error_code: int, message: str):
        socketio.emit('notification', {
            'success': success,
            'error_code': error_code,
            'message': message
        })

    #initiate ros process.
    def __ros(self):
        while rclpy.ok():
            try:
                rclpy.spin_once(self,timeout_sec=0.01)
            except Exception as e:
                try:
                    self.get_logger().error(f'ROS spin error: {e}')
                except Exception:
                    pass
    
    #initiate socket.
    def run_socket(self):
        port = int(os.environ.get('TRITON_GUI_PORT', '5050'))
        self.get_logger().info(f'Server starting at http://{self.__get_ip()}:{port}...')
        socketio.run(app, host='0.0.0.0', port=port, allow_unsafe_werkzeug=True)

    #destroy node override.
    def destroy_node(self):
        self.__is_shutting_down = True
        try:
            self.__db.close()
        except Exception:
            pass
        super().destroy_node()

def main():
    import argparse
    import sys
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--arabic', action='store_true', help='Use Arabic TTS audio')
    parser.add_argument('--no-oak', dest='no_oak', action='store_true',
                        help='Disable OAK-D camera entirely')
    cli_args, ros_args = parser.parse_known_args()

    if cli_args.arabic:
        app.config['TTS_LANG'] = 'ar'

    if cli_args.no_oak:
        os.environ['DEMO_MODE'] = '1'

    rclpy.init(args=ros_args)
    node = TritonGUINode()
    try:
        node.run_socket()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
